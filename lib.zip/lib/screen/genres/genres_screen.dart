import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:novelux/config/ThemeController.dart';
import 'package:novelux/config/app_style.dart';
import 'package:novelux/screen/book_preview/story_detail_screen.dart';
import 'package:novelux/screen/genres/controller/genres_controller.dart';
import 'package:novelux/widgets/custom_image_view.dart';

class GenresScreen extends StatelessWidget {
  const GenresScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ctrl = Get.put(GenresController());

    final theme = Get.find<ThemeController>();

    return AnimatedBuilder(
      animation: theme,
      builder: (_, __) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final bg = isDark ? const Color(0xFF0d0d0f) : const Color(0xFFF2F2F7);
        final cardBg =
            isDark ? const Color.fromARGB(255, 33, 35, 36) : Colors.white;
        final txt = isDark ? Colors.white : const Color(0xFF1a1a1a);
        final sub = isDark ? Colors.grey[400]! : Colors.grey[600]!;
        final divClr = isDark ? const Color(0xFF2a2a2a) : Colors.grey[200]!;

        return Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: bg,
            elevation: 0,
            title: Text(
              'Genres',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                fontFamily: 'Poppins',
                color: txt,
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.search, color: txt),
                onPressed: () {},
              ),
            ],
          ),
          body: Container(
            color: bg,
            child: Obx(() {
              if (ctrl.genres.isEmpty && ctrl.isLoading.value) {
                return Center(
                  child: Container(
                    height: 130,
                    width: 130,
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(31, 100, 100, 100),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: SpinKitWanderingCubes(
                      size: 30,
                      //color: depperBlue,
                      itemBuilder: (context, index) {
                        return DecoratedBox(
                          decoration: BoxDecoration(
                            color: index.isEven ? depperBlue : Colors.white,
                            shape: BoxShape.rectangle,
                          ),
                        );
                      },
                      //size: 50,
                      duration: const Duration(milliseconds: 1200),
                    ),
                  ),
                  // CircularProgressIndicator(
                  //   color: Colors.blue,
                  // ),
                );
              }
              return Row(
                children: [
                  // ── Left sidebar: genres ───────────────────────────────────────
                  SizedBox(
                    width: 95,
                    child: ListView.builder(
                      itemCount: ctrl.genres.length,
                      itemBuilder: (_, i) {
                        final genre = ctrl.genres[i];
                        final isSelected = ctrl.selectedIndex.value == i;
                        return GestureDetector(
                          onTap:
                              () =>
                                  ctrl.selectGenre(i, genre['slug'].toString()),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 14,
                            ),
                            decoration: BoxDecoration(
                              border: Border(
                                left: BorderSide(
                                  color:
                                      isSelected
                                          ? depperBlue
                                          : Colors.transparent,
                                  width: 3,
                                ),
                              ),
                            ),
                            child: Text(
                              genre['name'] ?? '',
                              style: TextStyle(
                                color: isSelected ? depperBlue : sub,
                                fontSize: 14,
                                fontFamily: 'Poppins',
                                fontWeight:
                                    isSelected
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),

                  // ── Right: stories for selected genre ─────────────────────────
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                        ),
                      ),
                      child: Obx(() {
                        if (ctrl.isLoading.value) {
                          return Center(
                            child: Container(
                              height: 130,
                              width: 130,
                              decoration: BoxDecoration(
                                color: const Color.fromARGB(31, 100, 100, 100),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: SpinKitWanderingCubes(
                                size: 30,
                                //color: depperBlue,
                                itemBuilder: (context, index) {
                                  return DecoratedBox(
                                    decoration: BoxDecoration(
                                      color:
                                          index.isEven
                                              ? depperBlue
                                              : Colors.white,
                                      shape: BoxShape.rectangle,
                                    ),
                                  );
                                },
                                //size: 50,
                                duration: const Duration(milliseconds: 1200),
                              ),
                            ),
                            // CircularProgressIndicator(
                            //   color: Colors.blue,
                            // ),
                          );
                        }
                        if (ctrl.stories.isEmpty) {
                          return Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.book_outlined,
                                  color: Colors.grey[700],
                                  size: 50,
                                ),
                                const SizedBox(height: 12),
                                const Text(
                                  'No stories in this genre yet',

                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontFamily: 'Poppins',
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }
                        return ListView.builder(
                          padding: const EdgeInsets.all(14),
                          itemCount: ctrl.stories.length,
                          itemBuilder: (_, i) {
                            final story = ctrl.stories[i];
                            final coverUrl = ctrl.getCoverUrl(story);
                            final tags = (story['tags'] as List? ?? []);
                            return GestureDetector(
                              onTap:
                                  () => Navigator.push(
                                    context,
                                    CupertinoPageRoute(
                                      builder:
                                          (_) => StoryDetailScreen(
                                            slug: story['slug'],
                                          ),
                                    ),
                                  ),
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 16),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Cover
                                    ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: SizedBox(
                                        width: 80,
                                        height: 108,
                                        child:
                                            coverUrl.isNotEmpty
                                                ? CustomImageView(
                                                  imagePath: coverUrl,
                                                  fit: BoxFit.cover,

                                                  //errorBuilder: (_, __, ___) => _placeholder()
                                                )
                                                : _placeholder(),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    // Details
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            story['title'] ?? '',
                                            style: TextStyle(
                                              color: txt,
                                              fontFamily: 'Poppins',
                                              fontSize: 16,
                                              fontWeight: FontWeight.w600,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            story['description'] ?? '',
                                            style: TextStyle(
                                              color: sub,
                                              fontFamily: 'Poppins',
                                              fontSize: 12,
                                              fontWeight: FontWeight.w500,
                                            ),
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 8),
                                          Row(
                                            children: [
                                              Text(
                                                '${double.tryParse(story['average_rating'].toString())?.toStringAsFixed(1) ?? '0.0'}',
                                                style: TextStyle(
                                                  color: sub,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w500,
                                                  fontFamily: 'Poppins',
                                                ),
                                              ),
                                              const SizedBox(width: 2),
                                              const Icon(
                                                Icons.star,
                                                color: Color(0xFFFFD700),
                                                size: 12,
                                              ),
                                              const SizedBox(width: 10),
                                              Text(
                                                '${story['total_views'] ?? 0} views',
                                                style: TextStyle(
                                                  color: sub,
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 11,
                                                ),
                                              ),
                                            ],
                                          ),
                                          const SizedBox(height: 6),
                                          if (tags.isNotEmpty)
                                            Container(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    horizontal: 8,
                                                    vertical: 3,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: depperBlue.withOpacity(
                                                  0.15,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                              ),
                                              child: Text(
                                                tags[0]['name'] ?? '',
                                                style: TextStyle(
                                                  color: depperBlue,
                                                  fontSize: 10,
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.w600,
                                                ),
                                              ),
                                            ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }),
                    ),
                  ),
                ],
              );
            }),
          ),
        );
      },
    );
  }

  Widget _placeholder() => Container(
    color: const Color(0xFF3a3a3a),
    child: const Center(child: Icon(Icons.book, color: Colors.grey, size: 28)),
  );
}
