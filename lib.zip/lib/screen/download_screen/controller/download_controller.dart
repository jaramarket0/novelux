import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:novelux/config/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer' as myLog;

// ── Models ────────────────────────────────────────────────────────────────────
class DownloadedChapter {
  final int number;
  final String title;
  final String content;
  final int wordCount;

  DownloadedChapter({
    required this.number,
    required this.title,
    required this.content,
  }) : wordCount =
           content.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).length;

  Map<String, dynamic> toJson() => {
    'number': number,
    'title': title,
    'content': content,
  };

  factory DownloadedChapter.fromJson(Map<String, dynamic> j) =>
      DownloadedChapter(
        number: j['number'] as int? ?? 1,
        title: j['title']?.toString() ?? '',
        content: j['content']?.toString() ?? '',
      );
}

class DownloadedStory {
  final String slug;
  final String title;
  final String author;
  final String coverUrl;
  final List<DownloadedChapter> chapters;
  final DateTime downloadedAt;

  const DownloadedStory({
    required this.slug,
    required this.title,
    required this.author,
    required this.coverUrl,
    required this.chapters,
    required this.downloadedAt,
  });

  int get totalWords => chapters.fold(0, (s, c) => s + c.wordCount);
  int get readMinutes => (totalWords / 200).ceil();

  Map<String, dynamic> toJson() => {
    'slug': slug,
    'title': title,
    'author': author,
    'coverUrl': coverUrl,
    'downloadedAt': downloadedAt.toIso8601String(),
    'chapters': chapters.map((c) => c.toJson()).toList(),
  };

  factory DownloadedStory.fromJson(Map<String, dynamic> j) => DownloadedStory(
    slug: j['slug']?.toString() ?? '',
    title: j['title']?.toString() ?? '',
    author: j['author']?.toString() ?? '',
    coverUrl: j['coverUrl']?.toString() ?? '',
    downloadedAt:
        DateTime.tryParse(j['downloadedAt']?.toString() ?? '') ??
        DateTime.now(),
    chapters:
        (j['chapters'] as List? ?? [])
            .map(
              (c) => DownloadedChapter.fromJson(Map<String, dynamic>.from(c)),
            )
            .toList(),
  );
}

// ── Controller ────────────────────────────────────────────────────────────────
class DownloadController extends GetxController {
  final RxBool isMarked = false.obs;
  final RxBool isAllSelected = false.obs;
  final RxList<DownloadedStory> downloads = <DownloadedStory>[].obs;
  final RxSet<String> selected = <String>{}.obs;
  final RxMap<String, double> progress = <String, double>{}.obs;
  final RxMap<String, String> downloadStatus = <String, String>{}.obs;
  // 'idle' | 'downloading' | 'done' | 'error'

  static const _kKey = 'nux_downloads_v2';

  @override
  void onInit() {
    super.onInit();
    _load();
  }

  // ── Persistence ─────────────────────────────────────────────────────────
  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_kKey);
    if (raw == null) return;
    try {
      final list = jsonDecode(raw) as List;
      downloads.value =
          list
              .map(
                (e) => DownloadedStory.fromJson(Map<String, dynamic>.from(e)),
              )
              .toList();
    } catch (e) {
      downloads.value = [];
    }
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _kKey,
      jsonEncode(downloads.map((d) => d.toJson()).toList()),
    );
  }

  // ── Status helpers ───────────────────────────────────────────────────────
  bool isDownloaded(String slug) => downloads.any((d) => d.slug == slug);

  String statusOf(String slug) =>
      downloadStatus[slug] ?? (isDownloaded(slug) ? 'done' : 'idle');

  DownloadedStory? getOffline(String slug) =>
      downloads.where((d) => d.slug == slug).firstOrNull;

  // ── Download ─────────────────────────────────────────────────────────────
  /// Downloads a full story with ALL chapter content from the API.
  /// Call this from the story detail screen or reading interface.
  Future<void> downloadStory({
    required String slug,
    required String title,
    required String author,
    required String coverUrl,
  }) async {
    if (isDownloaded(slug)) {
      Get.snackbar(
        'Already saved',
        '"$title" is already available offline',
        backgroundColor: const Color(0xFF2a2a2a),
        colorText: Colors.white,
        duration: const Duration(seconds: 2),
      );
      return;
    }

    if (downloadStatus[slug] == 'downloading') return;

    downloadStatus[slug] = 'downloading';
    progress[slug] = 0.0;

    // Show start toast
    Get.snackbar(
      '⬇ Downloading',
      'Saving "$title" for offline reading...',
      backgroundColor: const Color(0xFF1e1e22),
      colorText: Colors.white,
      showProgressIndicator: true,
      duration: const Duration(seconds: 3),
    );

    try {
      // 1. Get chapter list
      final chapRes = await ApiService.getChapters(slug);
      if (!chapRes['success']) throw Exception('Could not fetch chapters');

      final chapList =
          chapRes['data'] is List
              ? chapRes['data'] as List
              : (chapRes['data']['results'] as List? ?? []);

      if (chapList.isEmpty) throw Exception('No chapters found');

      final downloaded = <DownloadedChapter>[];

      // 2. Fetch FULL content for every chapter
      for (int i = 0; i < chapList.length; i++) {
        final chNum = chapList[i]['chapter_number'] as int? ?? (i + 1);
        final chTitle = chapList[i]['title']?.toString() ?? 'Chapter $chNum';

        // Fetch full chapter content
        final chRes = await ApiService.getChapter(slug, chNum);
        String content = '';
        if (chRes['success']) {
          content = chRes['data']['content']?.toString() ?? '';
        } else {
          // Fallback: use preview content if full fetch fails
          content = chapList[i]['content']?.toString() ?? '';
        }

        downloaded.add(
          DownloadedChapter(number: chNum, title: chTitle, content: content),
        );

        // Update progress
        progress[slug] = (i + 1) / chapList.length;
        myLog.log('Downloading chapter $i of ${chapList.length}');
        myLog.log(progress[slug].toString());
      }

      // 3. Save story with full content
      final story = DownloadedStory(
        slug: slug,
        title: title,
        author: author,
        coverUrl: coverUrl,
        chapters: downloaded,
        downloadedAt: DateTime.now(),
      );

      downloads.add(story);
      await _persist();

      downloadStatus[slug] = 'done';
      progress.remove(slug);

      Get.snackbar(
        '✅ Download complete!',
        '"$title" — ${downloaded.length} chapters · ${story.readMinutes} min read',
        backgroundColor: Colors.green,
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    } catch (e) {
      downloadStatus[slug] = 'error';
      progress.remove(slug);
      Get.snackbar(
        'Download failed',
        'Could not download "$title". Check your connection.',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  // ── Delete ───────────────────────────────────────────────────────────────
  Future<void> deleteDownload(String slug) async {
    downloads.removeWhere((d) => d.slug == slug);
    downloadStatus.remove(slug);
    await _persist();
    Get.snackbar(
      'Deleted',
      'Removed from downloads',
      backgroundColor: const Color(0xFF2a2a2a),
      colorText: Colors.white,
      duration: const Duration(seconds: 2),
    );
  }

  Future<void> deleteSelected() async {
    for (final slug in selected) {
      downloadStatus.remove(slug);
    }
    downloads.removeWhere((d) => selected.contains(d.slug));
    selected.clear();
    isMarked.value = false;
    await _persist();
  }

  void toggleSelect(String slug) {
    if (selected.contains(slug))
      selected.remove(slug);
    else
      selected.add(slug);
  }

  void selectAll() => selected.addAll(downloads.map((d) => d.slug));

  void clearSelection() {
    selected.clear();
    isMarked.value = false;
  }
}
