import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:novelux/config/api_service.dart';
import 'package:novelux/config/app_style.dart';
import 'package:novelux/screen/auth/auth_controller.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── Controller ────────────────────────────────────────────────────────────────
class RewardsController extends GetxController {
  final auth = Get.find<AuthController>();

  final RxInt  currentStreak     = 0.obs;
  final RxInt  todayDay          = 1.obs;
  final RxBool checkedInToday    = false.obs;
  final RxBool isClaimingCheckin = false.obs;
  final RxInt  readingMinutesToday = 0.obs;
  final RxInt  adsWatchedToday   = 0.obs;
  final int    maxAdsPerDay      = 5;
  final RxBool signInClaimed         = false.obs;
  final RxBool notificationsClaimed  = false.obs;

  final List<int> checkInRewards = [5, 5, 15, 15, 25, 25, 40];

  final List<Map<String, dynamic>> readingMilestones = [
    {'mins': 5,   'coins': 5},
    {'mins': 10,  'coins': 5},
    {'mins': 30,  'coins': 10},
    {'mins': 60,  'coins': 20},
    {'mins': 120, 'coins': 35},
    {'mins': 180, 'coins': 50},
  ];

  @override
  void onInit() {
    super.onInit();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final today = DateTime.now().toIso8601String().substring(0, 10);
    final saved = prefs.getString('checkin_date') ?? '';

    currentStreak.value       = prefs.getInt('checkin_streak') ?? 0;
    todayDay.value            = (currentStreak.value % 7) + 1;
    checkedInToday.value      = saved == today;
    adsWatchedToday.value     = saved == today ? (prefs.getInt('ads_today') ?? 0) : 0;
    readingMinutesToday.value = saved == today ? (prefs.getInt('reading_mins') ?? 0) : 0;
    signInClaimed.value       = prefs.getBool('signin_claimed') ?? false;
    notificationsClaimed.value= prefs.getBool('notif_claimed') ?? false;
  }

  Future<void> claimDailyCheckIn() async {
    if (checkedInToday.value || isClaimingCheckin.value) { return; }
    isClaimingCheckin.value = true;
    final prefs  = await SharedPreferences.getInstance();
    final today  = DateTime.now().toIso8601String().substring(0, 10);
    final reward = checkInRewards[(todayDay.value - 1).clamp(0, 6)];

    await ApiService.claimDailyReward(reward);
    isClaimingCheckin.value = false;
    checkedInToday.value    = true;
    currentStreak.value++;
    todayDay.value = (currentStreak.value % 7) + 1;
    await prefs.setString('checkin_date', today);
    await prefs.setInt('checkin_streak', currentStreak.value);
    auth.fetchMe();

    Get.snackbar('🎉 +$reward Coins!', 'Daily check-in claimed!',
        backgroundColor: Colors.orange, colorText: Colors.black,
        snackPosition: SnackPosition.TOP,
        duration: const Duration(seconds: 2));
  }

  Future<void> watchAd() async {
    if (adsWatchedToday.value >= maxAdsPerDay) { return; }
    Get.snackbar('📺 Coming Soon',
        'AdMob rewarded ads — integration in progress!',
        backgroundColor: const Color(0xFF2a2a2a), colorText: Colors.white);
  }

  Future<void> claimBenefit(String key, int coins, RxBool flag) async {
    if (flag.value) { return; }
    await ApiService.claimDailyReward(coins);
    flag.value = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(key, true);
    auth.fetchMe();
    Get.snackbar('✅ +$coins Coins', 'Reward claimed!',
        backgroundColor: Colors.green, colorText: Colors.white);
  }

  int get readingMilestoneIndex {
    for (int i = readingMilestones.length - 1; i >= 0; i--) {
      if (readingMinutesToday.value >= readingMilestones[i]['mins']) { return i; }
    }
    return -1;
  }

  double get readingProgress {
    final mi  = readingMilestoneIndex;
    final prev = mi >= 0 ? readingMilestones[mi]['mins'] as int : 0;
    final next = readingMilestones.firstWhere(
      (m) => readingMinutesToday.value < m['mins'],
      orElse: () => readingMilestones.last,
    )['mins'] as int;
    if (next == prev) { return 1.0; }
    return (readingMinutesToday.value - prev) / (next - prev);
  }
}

// ── Screen ────────────────────────────────────────────────────────────────────
class RewardsScreen extends StatelessWidget {
  const RewardsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final ctrl  = Get.put(RewardsController());
    final auth  = Get.find<AuthController>();
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg     = isDark ? const Color(0xFF0d0d0f) : const Color(0xFFF2F2F7);
    final card   = isDark ? const Color(0xFF1e1e22) : Colors.white;
    final txt    = isDark ? Colors.white : const Color(0xFF1a1a1a);
    final sub    = isDark ? Colors.grey[400]! : Colors.grey[600]!;
    final chip   = isDark ? const Color(0xFF2a2a30) : const Color(0xFFF0F0F0);
    final gold   = const Color(0xFF3d3800);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: isDark ? const Color(0xFF1a1a1a) : Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.chevron_left, color: txt, size: 28),
          onPressed: () => Get.back()),
        title: Column(children: [
          Text('Earn rewards', style: TextStyle(color: txt,
              fontSize: 16, fontWeight: FontWeight.w600)),
          Text('Coins can only be used on NoveluX',
              style: TextStyle(color: sub, fontSize: 11)),
        ]),
        centerTitle: true,
        actions: [IconButton(
          icon: Icon(Icons.more_vert, color: txt), onPressed: () {})],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // ── Balance card ────────────────────────────────────────────────
          _card(card, child: Column(children: [
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text('My coins ›', style: TextStyle(color: txt,
                      fontSize: 14, fontWeight: FontWeight.w500)),
                ]),
                const SizedBox(height: 2),
                Obx(() => Text('${auth.coins}', style: TextStyle(color: txt,
                    fontSize: 48, fontWeight: FontWeight.bold))),
                Obx(() => Text(
                  '≈ ${(auth.coins / 100).toStringAsFixed(0)} hours Ad-Free',
                  style: TextStyle(color: sub, fontSize: 12))),
              ]),
              const Spacer(),
              Container(
                decoration: BoxDecoration(
                    color: gold, borderRadius: BorderRadius.circular(24)),
                child: TextButton(
                  onPressed: () {},
                  child: const Text('Redeem', style: TextStyle(
                      color: Colors.orange,
                      fontWeight: FontWeight.bold, fontSize: 15)),
                ),
              ),
            ]),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                  color: chip, borderRadius: BorderRadius.circular(8)),
              child: Text('Use your coins before they expire.',
                  style: TextStyle(color: sub, fontSize: 12)),
            ),
          ])),
          const SizedBox(height: 14),

          // ── Daily check-in ──────────────────────────────────────────────
          _card(card, child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('Daily check-in', style: TextStyle(color: txt,
                  fontSize: 15, fontWeight: FontWeight.bold)),
              const Spacer(),
              Text('7-day streak:${ctrl.checkInRewards.reduce((a,b)=>a+b)} coins',
                  style: const TextStyle(color: Colors.orange, fontSize: 12)),
            ]),
            const SizedBox(height: 14),

            // Day boxes
            Obx(() => Row(children: List.generate(7, (i) {
              final day     = i + 1;
              final reward  = ctrl.checkInRewards[i];
              final claimed = day < ctrl.todayDay.value ||
                  (day == ctrl.todayDay.value && ctrl.checkedInToday.value);
              final isToday = day == ctrl.todayDay.value;
              return Expanded(child: Container(
                margin: const EdgeInsets.only(right: 4),
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 2),
                decoration: BoxDecoration(
                  color: claimed ? gold : chip,
                  borderRadius: BorderRadius.circular(10),
                  border: isToday && !claimed
                      ? Border.all(color: Colors.orange, width: 1.5) : null,
                ),
                child: Column(children: [
                  Text('+$reward', style: TextStyle(
                      color: claimed ? Colors.orange : sub,
                      fontSize: 11, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  claimed
                      ? const Icon(Icons.check_circle,
                          color: Colors.orange, size: 20)
                      : const Icon(Icons.star, color: Colors.orange, size: 20),
                  const SizedBox(height: 4),
                  Text(isToday ? 'Today' : 'day $day',
                      style: TextStyle(color: sub, fontSize: 9)),
                ]),
              ));
            }))),
            const SizedBox(height: 14),

            // Claim button
            Obx(() => SizedBox(
              width: double.infinity, height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: ctrl.checkedInToday.value
                      ? gold : Colors.orange,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(24)),
                ),
                onPressed: ctrl.checkedInToday.value
                    ? null : ctrl.claimDailyCheckIn,
                child: ctrl.isClaimingCheckin.value
                    ? const SizedBox(width: 20, height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : ctrl.checkedInToday.value
                        ? Row(mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.play_arrow,
                                  color: Colors.orange, size: 20),
                              const SizedBox(width: 8),
                              const Text('Earn 120 more coins',
                                  style: TextStyle(color: Colors.orange,
                                      fontWeight: FontWeight.bold)),
                            ])
                        : const Text('Claim today\'s reward',
                            style: TextStyle(color: Colors.black,
                                fontWeight: FontWeight.bold, fontSize: 15)),
              ),
            )),
          ])),
          const SizedBox(height: 14),

          // ── Daily rewards ────────────────────────────────────────────────
          _card(card, child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Daily rewards', style: TextStyle(color: txt,
                fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),

            // Reading challenge
            Row(children: [
              Text('Reading challenge', style: TextStyle(color: txt, fontSize: 14)),
              const Spacer(),
              GestureDetector(
                onTap: () {},
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
                  decoration: BoxDecoration(
                      color: Colors.orange,
                      borderRadius: BorderRadius.circular(20)),
                  child: const Text('Claim', style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold, fontSize: 13)),
                ),
              ),
            ]),
            const SizedBox(height: 14),

            // Milestone row
            Obx(() {
              final reached = ctrl.readingMilestoneIndex;
              return Column(children: [
                SizedBox(
                  height: 78,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: ctrl.readingMilestones.length,
                    itemBuilder: (_, i) {
                      final m      = ctrl.readingMilestones[i];
                      final isDone = i <= reached;
                      return Container(
                        width: 68, margin: const EdgeInsets.only(right: 8),
                        child: Column(children: [
                          Container(
                            width: 52, height: 52,
                            decoration: BoxDecoration(
                              color: isDone ? gold : chip,
                              borderRadius: BorderRadius.circular(10)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('+${m['coins']}', style: TextStyle(
                                    color: isDone ? Colors.orange : sub,
                                    fontSize: 12, fontWeight: FontWeight.bold)),
                                const Icon(Icons.star,
                                    color: Colors.orange, size: 16),
                              ]),
                          ),
                          const SizedBox(height: 4),
                          Text('${m['mins']}min',
                              style: TextStyle(color: sub, fontSize: 10)),
                        ]),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 8),
                ClipRRect(borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: ctrl.readingProgress.clamp(0.0, 1.0),
                    backgroundColor: chip,
                    color: Colors.orange,
                    minHeight: 5)),
              ]);
            }),
            const SizedBox(height: 18),
            Divider(color: isDark ? const Color(0xFF2a2a2a) : Colors.grey[200]!,
                height: 1),
            const SizedBox(height: 14),

            // Watch ads
            Row(children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Obx(() => Text(
                  'Watch ads (${ctrl.adsWatchedToday.value}/${ctrl.maxAdsPerDay})',
                  style: TextStyle(color: txt, fontSize: 14))),
                const SizedBox(height: 4),
                const Row(children: [
                  Icon(Icons.star, color: Colors.orange, size: 16),
                  SizedBox(width: 4),
                  Text('+100 coins', style: TextStyle(color: Colors.orange,
                      fontSize: 13, fontWeight: FontWeight.bold)),
                ]),
              ]),
              const Spacer(),
              Obx(() {
                final done = ctrl.adsWatchedToday.value >= ctrl.maxAdsPerDay;
                return GestureDetector(
                  onTap: ctrl.watchAd,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 8),
                    decoration: BoxDecoration(
                        color: done ? chip : gold,
                        borderRadius: BorderRadius.circular(20)),
                    child: Text('Go', style: TextStyle(
                        color: done ? Colors.grey : Colors.orange,
                        fontWeight: FontWeight.bold, fontSize: 14)),
                  ),
                );
              }),
            ]),
          ])),
          const SizedBox(height: 14),

          // ── General benefits ─────────────────────────────────────────────
          _card(card, child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('General benefits', style: TextStyle(color: txt,
                fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),

            Obx(() => _benefitRow('Sign in', '+30 coins', txt, sub, chip, gold,
                ctrl.signInClaimed.value,
                () => ctrl.claimBenefit('signin_claimed', 30, ctrl.signInClaimed))),
            const SizedBox(height: 14),
            Divider(color: isDark ? const Color(0xFF2a2a2a) : Colors.grey[200]!,
                height: 1),
            const SizedBox(height: 14),
            Obx(() => _benefitRow('Enable notifications', '+200 coins',
                txt, sub, chip, gold,
                ctrl.notificationsClaimed.value,
                () => ctrl.claimBenefit(
                    'notif_claimed', 200, ctrl.notificationsClaimed))),
          ])),
          const SizedBox(height: 30),

          Center(child: Text('Terms and Conditions',
              style: TextStyle(color: Colors.grey[600], fontSize: 13))),
          const SizedBox(height: 30),
        ]),
      ),
    );
  }

  Widget _card(Color bg, {required Widget child}) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)),
    child: child,
  );

  Widget _benefitRow(String title, String reward, Color txt, Color sub,
      Color chip, Color gold, bool claimed, VoidCallback onClaim) =>
    Row(children: [
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(color: txt, fontSize: 14)),
        const SizedBox(height: 4),
        Row(children: [
          const Icon(Icons.star, color: Colors.orange, size: 16),
          const SizedBox(width: 4),
          Text(reward, style: const TextStyle(color: Colors.orange,
              fontSize: 13, fontWeight: FontWeight.bold)),
        ]),
      ]),
      const Spacer(),
      GestureDetector(
        onTap: claimed ? null : onClaim,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
              color: claimed ? chip : gold,
              borderRadius: BorderRadius.circular(20)),
          child: Text(claimed ? 'Done' : 'Claim',
              style: TextStyle(
                  color: claimed ? Colors.grey : Colors.orange,
                  fontWeight: FontWeight.bold, fontSize: 14)),
        ),
      ),
    ]);
}