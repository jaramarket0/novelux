import 'dart:developer' as myLog;
// import 'package:animated_text_kit/animated_text_kit.dart';
// import 'package:carousel_slider/carousel_slider.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:novelux/config/ThemeController.dart';
// import 'package:novelux/config/app_style.dart';
// // import 'package:novelux/config/theme_controller.dart';
// import 'package:novelux/screen/book_preview/story_detail_screen.dart';
// import 'package:novelux/screen/explore/controller/explore_controller.dart';
// import 'package:novelux/screen/view_all_screen/view_all_screen.dart';
// import 'package:novelux/widgets/custom_image_view.dart';
// import 'package:shimmer/shimmer.dart';
// import 'dart:developer' as
//
// ;

// class ExploreScreen extends StatefulWidget {
//   const ExploreScreen({super.key});
//   @override
//   _ExploreScreenState createState() => _ExploreScreenState();
// }

// class _ExploreScreenState extends State<ExploreScreen> {
//   final ctrl = Get.put(ExploreController());
//   final themeCtrl = Get.find<ThemeController>();
//   final searchCtrl = TextEditingController();
//   int selectedCategoryIndex = 0;
//   int selectedRankingIndex = 0;
//   int _current = 0;

//   CarouselController carouselController = CarouselController();

//   final List<String> promoImages = [
//     'assets/images/promotion1.png',
//     'assets/images/promotion2.png',
//     'assets/images/promotion3.png',
//   ];

//   final List<String> promoSlugs = [
//     'story-slug-1', // Replace with actual story slugs
//     'story-slug-2',
//     'story-slug-3',
//   ];

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       extendBody: true,
//       extendBodyBehindAppBar: false,
//       backgroundColor: const Color(0xFF1A1A1A),
//       floatingActionButton: Obx(
//         () => FloatingActionButton(
//           onPressed: themeCtrl.toggleTheme,
//           child: Icon(
//             themeCtrl.themeMode == ThemeMode.light
//                 ? Icons.dark_mode
//                 : themeCtrl.themeMode == ThemeMode.dark
//                 ? Icons.brightness_auto
//                 : Icons.light_mode,
//           ),
//         ),
//       ),
//       body: SafeArea(
//         bottom: false,
//         child: Column(
//           children: [
//             // Search bar
//             Container(
//               padding: const EdgeInsets.all(16),
//               child: GestureDetector(
//                 onTap: () => _showSearch(context),
//                 child: Container(
//                   padding: const EdgeInsets.symmetric(
//                     horizontal: 12,
//                     vertical: 10,
//                   ),
//                   decoration: BoxDecoration(
//                     color: const Color(0xFF2A2A2A),
//                     borderRadius: BorderRadius.circular(25),
//                   ),
//                   child: Row(
//                     children: [
//                       const Icon(Icons.search, color: Colors.grey, size: 18),
//                       const SizedBox(width: 10),
//                       Expanded(
//                         child: AnimatedTextKit(
//                           repeatForever: true,
//                           // textList: [
//                           //   'Search novels, authors, genres...',
//                           //   'The Ashboard CRown',
//                           //   'sweet home alabama',
//                           //   'sweet chaos',
//                           //   'luna\'s betrayal',
//                           //   'unexpected desires'
//                           // ],
//                           // style: TextStyle(color: Colors.grey, fontSize: 12),
//                           // speed: const Duration(milliseconds: 100),
//                           animatedTexts: [
//                             //  FadeAnimatedText
//                             FadeAnimatedText(
//                               textStyle: TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 12,
//                               ),
//                               'Search novels, authors, genres...',
//                               duration: const Duration(milliseconds: 5000),
//                             ),
//                             FadeAnimatedText(
//                               textStyle: TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 12,
//                               ),
//                               'The Ashboard CRown',
//                               duration: const Duration(milliseconds: 5000),
//                             ),
//                             FadeAnimatedText(
//                               textStyle: TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 12,
//                               ),
//                               'sweet home alabama',
//                               duration: const Duration(milliseconds: 5000),
//                             ),
//                             FadeAnimatedText(
//                               textStyle: TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 12,
//                               ),
//                               'sweet chaos',
//                               duration: const Duration(milliseconds: 5000),
//                             ),
//                             FadeAnimatedText(
//                               textStyle: TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 12,
//                               ),
//                               'luna\'s betrayal',
//                               duration: const Duration(milliseconds: 5000),
//                             ),
//                             FadeAnimatedText(
//                               textStyle: TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 12,
//                               ),
//                               'unexpected desires',
//                               duration: const Duration(milliseconds: 5000),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ),

//             Expanded(
//               child: RefreshIndicator(
//                 onRefresh: ctrl.fetchAll,
//                 color: depperBlue,
//                 child: SingleChildScrollView(
//                   physics: const AlwaysScrollableScrollPhysics(),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       // ── Featured Carousel ─────────────────────────────────────
//                       Obx(
//                         () =>
//                             ctrl.featured.isNotEmpty
//                                 ? _section('Featured', _buildFeaturedCarousel())
//                                 : ctrl.isLoadingFeatured.value
//                                 ? _shimmerRow()
//                                 : const SizedBox.shrink(),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── For You / Genre filtered ──────────────────────────────
//                       _section(
//                         'For You',
//                         Column(
//                           children: [
//                             _genreTabs(),
//                             const SizedBox(height: 12),
//                             Obx(
//                               () =>
//                                   ctrl.forYou.isEmpty
//                                       ? _shimmerRow()
//                                       : _storyRow(ctrl.forYou),
//                             ),
//                           ],
//                         ),
//                       ),

//                       const SizedBox(height: 10),
//                       Padding(
//                         padding: const EdgeInsets.symmetric(horizontal: 10.0),
//                         child: Stack(
//                           alignment:
//                               Alignment.bottomRight, // Positions the counter
//                           children: [
//                             SizedBox(
//                               width:
//                                   double
//                                       .infinity, // Ensures the container takes full width
//                               height:
//                                   100, // Increased height slightly for better visibility
//                               child: CarouselSlider.builder(
//                                 itemCount: promoImages.length,
//                                 itemBuilder: (
//                                   BuildContext context,
//                                   int index,
//                                   int realIndex,
//                                 ) {
//                                   return Container(
//                                     width:
//                                         MediaQuery.of(
//                                           context,
//                                         ).size.width, // Full screen width
//                                     decoration: BoxDecoration(
//                                       borderRadius: BorderRadius.circular(15),
//                                     ),
//                                     child: ClipRRect(
//                                       borderRadius: BorderRadius.circular(15),
//                                       child: CustomImageView(
//                                         onTap:
//                                             () => Navigator.push(
//                                               context,
//                                               CupertinoPageRoute(
//                                                 builder:
//                                                     (_) => StoryDetailScreen(
//                                                       slug: promoSlugs[index],
//                                                     ),
//                                               ),
//                                             ),
//                                         imagePath: promoImages[index],
//                                         fit: BoxFit.cover,
//                                         width:
//                                             MediaQuery.of(context).size.width,
//                                       ),
//                                     ),
//                                   );
//                                 },
//                                 options: CarouselOptions(
//                                   height: 100,
//                                   autoPlay: true,
//                                   viewportFraction:
//                                       1.0, // This makes it span across the screen
//                                   enlargeCenterPage:
//                                       false, // Turn off to keep it flat and full-width
//                                   autoPlayInterval: const Duration(seconds: 5),
//                                   onPageChanged: (index, reason) {
//                                     setState(() {
//                                       _current =
//                                           index; // Update your index variable here
//                                     });
//                                   },
//                                 ),
//                               ),
//                             ),

//                             // The Counter Overlay
//                             Padding(
//                               padding: const EdgeInsets.all(12.0),
//                               child: AnimatedContainer(
//                                 duration: const Duration(milliseconds: 300),
//                                 padding: const EdgeInsets.symmetric(
//                                   horizontal: 8,
//                                   vertical: 4,
//                                 ),
//                                 decoration: BoxDecoration(
//                                   color: Colors.black.withOpacity(0.0),
//                                   borderRadius: BorderRadius.circular(12),
//                                 ),
//                                 child: Row(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children:
//                                       promoImages.asMap().entries.map((entry) {
//                                         return Container(
//                                           width:
//                                               _current == entry.key
//                                                   ? 12.0
//                                                   : 8.0, // Active dot is slightly wider
//                                           height: 8.0,
//                                           margin: const EdgeInsets.symmetric(
//                                             horizontal: 4.0,
//                                           ),
//                                           decoration: BoxDecoration(
//                                             shape: BoxShape.circle,
//                                             color: depperBlue.withOpacity(
//                                               _current == entry.key
//                                                   ? 0.9
//                                                   : 0.4, // Active dot is brighter
//                                             ),
//                                           ),
//                                         );
//                                       }).toList(),
//                                 ),
//                                 // Text(
//                                 //   "${_current + 1} / ${promoImages.length}",
//                                 //   style: const TextStyle(
//                                 //     color: Colors.white,
//                                 //     fontSize: 12,
//                                 //     fontWeight: FontWeight.bold,
//                                 //   ),
//                                 // ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),

//                       const SizedBox(height: 10),
//                       // ── Rankings ──────────────────────────────────────────────
//                       _section(
//                         'Best Novels',
//                         Column(
//                           children: [
//                             _tabRow(
//                               ['Must Read', 'Most Engaging', 'Top Rated'],
//                               selectedRankingIndex,
//                               (i) => setState(() => selectedRankingIndex = i),
//                             ),
//                             const SizedBox(height: 10),
//                             Obx(
//                               () =>
//                                   ctrl.trending.isEmpty
//                                       ? _shimmerRow()
//                                       : _rankingsList(ctrl.trending),
//                             ),
//                           ],
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── Trending ──────────────────────────────────────────────
//                       _section(
//                         'Trending Now',
//                         Obx(
//                           () =>
//                               ctrl.trending.isEmpty
//                                   ? _shimmerRow()
//                                   : _storyRow(ctrl.trending),
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── Completed Stories ──────────────────────────────────────────────
//                       _section(
//                         'Completed Stories',
//                         Obx(
//                           () =>
//                               ctrl.completedStories.isEmpty
//                                   ? _shimmerRow()
//                                   : _storyRow(ctrl.completedStories),
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── World Famous ──────────────────────────────────────────────
//                       _section(
//                         'World Famous',
//                         Obx(
//                           () =>
//                               ctrl.worldFamous.isEmpty
//                                   ? _shimmerRow()
//                                   : _storyRow(ctrl.worldFamous),
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── Free Download ──────────────────────────────────────────────
//                       _section(
//                         'Free DownLoad',
//                         Obx(
//                           () =>
//                               ctrl.freeDownLoad.isEmpty
//                                   ? _shimmerRow()
//                                   : _storyRow(ctrl.freeDownLoad),
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── Free Download ──────────────────────────────────────────────
//                       _section(
//                         'African Folk Tale',
//                         Obx(
//                           () =>
//                               ctrl.africanfolktale.isEmpty
//                                   ? _shimmerRow()
//                                   : _storyRow(ctrl.africanfolktale),
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── Editor's Pick ─────────────────────────────────────────
//                       _section(
//                         "Editor's Pick",
//                         Obx(
//                           () =>
//                               ctrl.editorsPick.isEmpty
//                                   ? _shimmerRow()
//                                   : _storyRow(ctrl.editorsPick),
//                         ),
//                       ),

//                       const SizedBox(height: 10),

//                       // ── Editor's Pick ─────────────────────────────────────────
//                       _section(
//                         "Featured For You",
//                         Obx(
//                           () =>
//                               ctrl.featured.isEmpty
//                                   ? _shimmerRow()
//                                   : _featuredList(ctrl.editorsPick),
//                         ),
//                       ),

//                       const SizedBox(height: 100),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _section(String title, Widget child) => Container(
//     margin: const EdgeInsets.symmetric(horizontal: 10),
//     decoration: BoxDecoration(
//       borderRadius: BorderRadius.circular(12),
//       color: Colors.grey[900],
//     ),
//     child: Column(
//       children: [_sectionHeader(title), child, const SizedBox(height: 10)],
//     ),
//   );

//   Widget _sectionHeader(String title) => Padding(
//     padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//     child: Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           title,
//           style: const TextStyle(
//             color: Colors.white,
//             fontSize: 12,
//             fontWeight: FontWeight.bold,
//           ),
//         ),
//         GestureDetector(
//           onTap: () => Get.to(() => ViewAllScreen(), arguments: title),
//           child: Row(
//             children: [
//               const Text(
//                 'View all',
//                 style: TextStyle(color: Colors.grey, fontSize: 12),
//               ),
//               const Icon(Icons.chevron_right, color: Colors.grey, size: 16),
//             ],
//           ),
//         ),
//       ],
//     ),
//   );

//   Widget _genreTabs() => Obx(() {
//     final genres = [
//       {'name': 'All', 'slug': ''},
//       ...ctrl.genres,
//     ];
//     return Container(
//       height: 28,
//       margin: const EdgeInsets.only(left: 16),
//       child: ListView.builder(
//         scrollDirection: Axis.horizontal,
//         itemCount: genres.length,
//         itemBuilder: (_, i) {
//           final isSelected = i == selectedCategoryIndex;
//           return GestureDetector(
//             onTap: () {
//               setState(() => selectedCategoryIndex = i);
//               final slug = genres[i]['slug'] ?? '';
//               if (slug.isEmpty) {
//                 ctrl.fetchForYou();
//               } else {
//                 ctrl.filterByGenre(slug.toString());
//               }
//             },
//             child: Container(
//               margin: const EdgeInsets.only(right: 8),
//               padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
//               decoration: BoxDecoration(
//                 color: isSelected ? depperBlue : const Color(0xFF2A2A2A),
//                 borderRadius: BorderRadius.circular(20),
//               ),
//               child: Text(
//                 genres[i]['name']?.toString() ?? '',
//                 style: TextStyle(
//                   color: isSelected ? Colors.white : Colors.white70,
//                   fontSize: 11,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   });

//   Widget _tabRow(List<String> tabs, int selected, Function(int) onTap) =>
//       Container(
//         height: 28,
//         margin: const EdgeInsets.only(left: 16),
//         child: ListView.builder(
//           scrollDirection: Axis.horizontal,
//           itemCount: tabs.length,
//           itemBuilder: (_, i) {
//             final isSel = i == selected;
//             return GestureDetector(
//               onTap: () => onTap(i),
//               child: Container(
//                 margin: const EdgeInsets.only(right: 8),
//                 padding: const EdgeInsets.symmetric(
//                   horizontal: 14,
//                   vertical: 5,
//                 ),
//                 decoration: BoxDecoration(
//                   color: isSel ? depperBlue : const Color(0xFF2A2A2A),
//                   borderRadius: BorderRadius.circular(20),
//                 ),
//                 child: Text(
//                   tabs[i],
//                   style: TextStyle(
//                     color: isSel ? Colors.white : Colors.white70,
//                     fontSize: 11,
//                     fontWeight: FontWeight.bold,
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       );

// Widget _buildFeaturedCarousel() => Obx(() {
//   if (ctrl.featured.isEmpty) {
//     return const SizedBox(
//       height: 170,
//       child: Center(child: CircularProgressIndicator(color: Colors.blue)),
//     );
//   }
//   return Container(
//     height: 170,
//     child: CarouselView(
//       itemExtent:
//           MediaQuery.of(context).size.width *
//           0.8, // Shows 80% of one card, hinting at the next
//       shrinkExtent:
//           MediaQuery.of(context).size.width *
//           0.7, // Minimum size when shrinking
//       children:
//           ctrl.featured.map((story) {
//             final coverUrl = ctrl.getCoverUrl(story);
//             return Material(
//               color: Colors.transparent,
//               child: InkWell(
//                 onTap: () {
//                   myLog.log('pushing now');
//                   Navigator.push(
//                     context,
//                     CupertinoPageRoute(
//                       builder: (_) => StoryDetailScreen(slug: story['slug']),
//                     ),
//                   );
//                 },
//                 child: Container(
//                   decoration: BoxDecoration(
//                     borderRadius: BorderRadius.circular(10),
//                     color: const Color(0xFF2A2A2A),
//                   ),
//                   child: ClipRRect(
//                     borderRadius: BorderRadius.circular(10),
//                     child: Stack(
//                       children: [
//                         // ✅ Force image to fill entire container
//                         Positioned.fill(
//                           child:
//                               coverUrl.isNotEmpty
//                                   ? CustomImageView(
//                                     imagePath: coverUrl,
//                                     fit: BoxFit.cover,
//                                     placeHolder: coverUrl,
//                                   )
//                                   : _bookPlaceholder(),
//                         ),

//                         // ✅ Bottom gradient overlay
//                         Positioned(
//                           bottom: 0,
//                           left: 0,
//                           right: 0,
//                           child: Container(
//                             height: 100,
//                             decoration: BoxDecoration(
//                               gradient: LinearGradient(
//                                 begin: Alignment.topCenter,
//                                 end: Alignment.bottomCenter,
//                                 colors: [
//                                   Colors.transparent,
//                                   Colors.black.withOpacity(1),
//                                 ],
//                               ),
//                             ),
//                           ),
//                         ),

//                         Positioned(
//                           top: 10,
//                           right: 10,
//                           child: Container(
//                             padding: EdgeInsets.all(3),
//                             decoration: BoxDecoration(
//                               color: depperBlue,
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//                             child: Row(
//                               children: [
//                                 ...(story['total_views'] != null
//                                     ? [
//                                       Text(
//                                         '${story['total_views']} Views ',
//                                         style: TextStyle(
//                                           color: Colors.white70,
//                                           fontSize: 10,
//                                           fontWeight: FontWeight.w900,
//                                         ),
//                                       ),
//                                     ]
//                                     : []),
//                                 Text(
//                                   ' ${story['average_rating']} ⭐',
//                                   style: TextStyle(
//                                     color: Colors.white70,
//                                     fontSize: 10,
//                                     fontWeight: FontWeight.w900,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         ),

//                         // ✅ Text
//                         Positioned(
//                           bottom: 12,
//                           left: 12,
//                           right: 12,
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               Text(
//                                 story['title'] ?? '',
//                                 style: const TextStyle(
//                                   color: Colors.white,
//                                   fontSize: 16,
//                                   fontFamily: 'Poppins',
//                                   fontWeight: FontWeight.w900,
//                                 ),
//                                 maxLines: 2,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                               const SizedBox(height: 4),
//                               Text(
//                                 story['description'] ?? '',
//                                 style: const TextStyle(
//                                   color: Colors.white70,
//                                   fontSize: 12,
//                                   fontFamily: 'Poppins',
//                                   fontWeight: FontWeight.w600,
//                                 ),
//                                 maxLines: 2,
//                                 overflow: TextOverflow.ellipsis,
//                               ),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             );
//           }).toList(),
//     ),
//   );
// });

//   Widget _storyRow(RxList stories) => SizedBox(
//     height: 200,
//     child: ListView.builder(
//       scrollDirection: Axis.horizontal,
//       padding: const EdgeInsets.symmetric(horizontal: 16),
//       itemCount: stories.length,
//       itemBuilder: (_, i) {
//         final story = stories[i];
//         final coverUrl = ctrl.getCoverUrl(story);
//         final tags = (story['tags'] as List? ?? []);
//         return GestureDetector(
//           onTap: () {
//             myLog.log('Tapped on ${story['title']} -  - cover: $coverUrl');
//             Navigator.push(
//               context,
//               CupertinoPageRoute(
//                 builder: (_) => StoryDetailScreen(slug: story['slug']),
//               ),
//             );
//           },
//           child: Container(
//             width: 85,
//             margin: const EdgeInsets.only(right: 12),
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 ClipRRect(
//                   borderRadius: BorderRadius.circular(8),
//                   child: SizedBox(
//                     height: 120,
//                     width: 85,
//                     child:
//                         coverUrl.isNotEmpty
//                             ? CustomImageView(
//                               imagePath: coverUrl,
//                               fit: BoxFit.cover,
//                               //errorBuilder: (_, __, ___) => _bookPlaceholder(),
//                             )
//                             : _bookPlaceholder(),
//                   ),
//                 ),
//                 const SizedBox(height: 6),
//                 Text(
//                   story['title'] ?? '',
//                   style: const TextStyle(
//                     color: Colors.white,
//                     fontSize: 13,
//                     fontWeight: FontWeight.w800,
//                   ),
//                   maxLines: 2,
//                   overflow: TextOverflow.ellipsis,
//                 ),
//                 if (tags.isNotEmpty)
//                   Container(
//                     margin: const EdgeInsets.only(top: 4),
//                     padding: const EdgeInsets.symmetric(
//                       horizontal: 4,
//                       vertical: 2,
//                     ),
//                     decoration: BoxDecoration(
//                       color: depperBlue.withOpacity(0.15),
//                       borderRadius: BorderRadius.circular(4),
//                     ),
//                     child: Text(
//                       tags[0]['name'] ?? '',
//                       style: TextStyle(
//                         color: depperBlue,
//                         fontSize: 10,
//                         fontWeight: FontWeight.w700,
//                       ),
//                     ),
//                   ),
//               ],
//             ),
//           ),
//         );
//       },
//     ),
//   );

//   Widget _rankingsList(RxList stories) => SizedBox(
//     height: 300,
//     child: GridView.builder(
//       shrinkWrap: true,
//       physics: const BouncingScrollPhysics(),
//       scrollDirection: Axis.horizontal,
//       itemCount: stories.length > 9 ? 9 : stories.length,
//       gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
//         mainAxisSpacing: 2,
//         crossAxisSpacing: 2,
//         childAspectRatio: 2.4 / 5.3,
//         crossAxisCount: 3,
//       ),
//       itemBuilder: (_, i) {
//         final story = stories[i];
//         final coverUrl = ctrl.getCoverUrl(story);
//         final tags = (story['tags'] as List? ?? []);
//         return Container(
//           margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
//           child: GestureDetector(
//             onTap:
//                 () => Navigator.push(
//                   context,
//                   CupertinoPageRoute(
//                     builder: (_) => StoryDetailScreen(slug: story['slug']),
//                   ),
//                 ),
//             child: Row(
//               children: [
//                 Stack(
//                   children: [
//                     ClipRRect(
//                       borderRadius: BorderRadius.circular(4),
//                       child: SizedBox(
//                         width: 55,
//                         height: 75,
//                         child:
//                             coverUrl.isNotEmpty
//                                 ? CustomImageView(
//                                   imagePath: coverUrl,
//                                   fit: BoxFit.cover,
//                                   //errorBuilder: (_, __, ___) => _bookPlaceholder(),
//                                 )
//                                 : _bookPlaceholder(),
//                       ),
//                     ),
//                     Positioned(
//                       child: Container(
//                         width: 15,
//                         height: 20,
//                         decoration: BoxDecoration(
//                           color: i < 3 ? depperBlue : const Color(0xFFA9AA6C),
//                           borderRadius: BorderRadius.circular(4),
//                         ),
//                         child: Center(
//                           child: Text(
//                             '${i + 1}',
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontWeight: FontWeight.bold,
//                               fontSize: 10,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 const SizedBox(width: 8),
//                 Expanded(
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Text(
//                         story['title'] ?? '',
//                         style: const TextStyle(
//                           color: Colors.white,
//                           fontFamily: 'Poppins',
//                           fontSize: 14,
//                           fontWeight: FontWeight.w700,
//                         ),
//                         maxLines: 1,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                       const SizedBox(height: 4),
//                       Text(
//                         story['description'] ?? '',
//                         style: const TextStyle(
//                           fontFamily: 'Poppins',
//                           color: Colors.grey,
//                           fontSize: 12,
//                           fontWeight: FontWeight.w700,
//                         ),
//                         maxLines: 1,
//                         overflow: TextOverflow.ellipsis,
//                       ),
//                       const SizedBox(height: 4),
//                       Row(
//                         children: [
//                           Text(
//                             '${double.tryParse(story['average_rating'].toString())?.toStringAsFixed(1) ?? '0.0'}',
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 10,
//                             ),
//                           ),
//                           const Icon(Icons.star, color: Colors.amber, size: 10),
//                           SizedBox(width: 8),
//                           Text(
//                             '${double.tryParse(story['total_views'].toString())?.toStringAsFixed(1)} views',
//                             style: const TextStyle(
//                               color: Colors.white,
//                               fontSize: 10,
//                             ),
//                           ),
//                         ],
//                       ),
//                       if (tags.isNotEmpty)
//                         Container(
//                           margin: const EdgeInsets.only(top: 4),
//                           padding: const EdgeInsets.symmetric(
//                             horizontal: 4,
//                             vertical: 2,
//                           ),
//                           decoration: BoxDecoration(
//                             color: depperBlue.withOpacity(0.15),
//                             borderRadius: BorderRadius.circular(4),
//                           ),
//                           child: Text(
//                             tags[0]['name'] ?? '',
//                             style: TextStyle(
//                               color: depperBlue,
//                               fontSize: 10,
//                               fontWeight: FontWeight.w700,
//                             ),
//                           ),
//                         ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         );
//       },
//     ),
//   );

//   Widget _featuredList(RxList stories) => Column(
//     children:
//         stories.take(6).map((story) {
//           final coverUrl = ctrl.getCoverUrl(story);
//           return GestureDetector(
//             onTap:
//                 () => Navigator.push(
//                   context,
//                   CupertinoPageRoute(
//                     builder: (_) => StoryDetailScreen(slug: story['slug']),
//                   ),
//                 ),
//             child: Container(
//               margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
//               child: Row(
//                 children: [
//                   ClipRRect(
//                     borderRadius: BorderRadius.circular(6),
//                     child: SizedBox(
//                       width: 75,
//                       height: 100,
//                       child:
//                           coverUrl.isNotEmpty
//                               ? CustomImageView(
//                                 imagePath: coverUrl,
//                                 fit: BoxFit.cover,
//                               )
//                               : _bookPlaceholder(),
//                     ),
//                   ),
//                   const SizedBox(width: 12),
//                   Expanded(
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text(
//                           story['title'] ?? '',
//                           style: const TextStyle(
//                             color: Colors.white,
//                             fontSize: 16,
//                             fontFamily: 'Poppins',
//                             fontWeight: FontWeight.w700,
//                           ),
//                           maxLines: 1,
//                           overflow: TextOverflow.ellipsis,
//                         ),
//                         const SizedBox(height: 4),
//                         Text(
//                           story['description'] ?? '',
//                           style: const TextStyle(
//                             color: Colors.grey,
//                             fontSize: 12,
//                             fontFamily: 'Poppins',
//                             fontWeight: FontWeight.w600,
//                           ),
//                           maxLines: 2,
//                           overflow: TextOverflow.ellipsis,
//                         ),
//                         const SizedBox(height: 4),
//                         Row(
//                           children: [
//                             Text(
//                               '${double.tryParse(story['average_rating'].toString())?.toStringAsFixed(1) ?? '0.0'}',
//                               style: const TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 11,
//                               ),
//                             ),
//                             const Icon(
//                               Icons.star,
//                               color: Colors.amber,
//                               size: 12,
//                             ),
//                             const SizedBox(width: 8),
//                             Text(
//                               '${story['total_views'] ?? 0} views',
//                               style: const TextStyle(
//                                 color: Colors.grey,
//                                 fontSize: 11,
//                               ),
//                             ),
//                           ],
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           );
//         }).toList(),
//   );

//   Widget _shimmerRow() => Shimmer(
//     gradient: LinearGradient(
//       colors: [Colors.grey[800]!, Colors.grey[700]!, Colors.grey[800]!],
//       stops: const [0.1, 0.3, 0.4],
//       begin: Alignment(-1, -0.3),
//       end: Alignment(1, 0.3),
//     ),
//     child: Container(
//       height: 170,
//       margin: const EdgeInsets.symmetric(horizontal: 16),
//       child: ListView.builder(
//         scrollDirection: Axis.horizontal,
//         itemCount: 4,
//         itemBuilder:
//             (_, __) => Container(
//               width: 85,
//               margin: const EdgeInsets.only(right: 12),
//               decoration: BoxDecoration(
//                 color: const Color(0xFF2A2A2A),
//                 borderRadius: BorderRadius.circular(8),
//               ),
//             ),
//       ),
//     ),
//   );

//   Widget _bookPlaceholder() => Container(
//     color: const Color(0xFF2A2A2A),
//     child: const Center(child: Icon(Icons.book, color: Colors.grey, size: 30)),
//   );

//   void _showSearch(BuildContext context) {
//     showSearch(context: context, delegate: _StorySearchDelegate(ctrl));
//   }
// }

// class _StorySearchDelegate extends SearchDelegate {
//   final ExploreController ctrl;
//   _StorySearchDelegate(this.ctrl);

//   @override
//   ThemeData appBarTheme(BuildContext context) => ThemeData.dark().copyWith(
//     appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF1a1a1a)),
//   );

//   @override
//   List<Widget> buildActions(BuildContext context) => [
//     IconButton(icon: const Icon(Icons.clear), onPressed: () => query = ''),
//   ];

//   @override
//   Widget buildLeading(BuildContext context) => IconButton(
//     icon: const Icon(Icons.arrow_back),
//     onPressed: () => close(context, null),
//   );

//   @override
//   Widget buildResults(BuildContext context) {
//     ctrl.search(query);
//     return Obx(
//       () => ListView.builder(
//         itemCount: ctrl.forYou.length,
//         itemBuilder: (_, i) {
//           final story = ctrl.forYou[i];
//           return ListTile(
//             leading: const Icon(Icons.book, color: Colors.grey),
//             title: Text(
//               story['title'] ?? '',
//               style: const TextStyle(color: Colors.white),
//             ),
//             subtitle: Text(
//               story['author']?['username'] ?? '',
//               style: const TextStyle(color: Colors.grey),
//             ),
//             onTap: () {
//               close(context, null);
//               Navigator.push(
//                 context,
//                 CupertinoPageRoute(
//                   builder: (_) => StoryDetailScreen(slug: story['slug']),
//                 ),
//               );
//             },
//           );
//         },
//       ),
//     );
//   }

//   @override
//   Widget buildSuggestions(BuildContext context) => buildResults(context);
// }

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import 'package:novelux/config/ThemeController.dart';
import 'package:novelux/config/app_style.dart';
import 'package:novelux/screen/book_preview/story_detail_screen.dart';
import 'package:novelux/screen/explore/controller/explore_controller.dart';
import 'package:novelux/screen/explore/lazy_story_loading.dart';
import 'package:novelux/screen/explore/search.dart';
import 'package:novelux/screen/reward_screen/reward_screen.dart';
import 'package:novelux/screen/view_all_screen/view_all_screen.dart';
import 'package:novelux/widgets/custom_image_view.dart';
import 'package:shimmer/shimmer.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});
  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  late final ExploreController ctrl;
  int _rankingIndex = 0;
  int _bannerIndex = 0;
  PageController? _bannerCtrl;

  @override
  void initState() {
    super.initState();
    ctrl = Get.put(ExploreController());
    _bannerCtrl = PageController(viewportFraction: 1.0);
    // Auto-advance banner every 5s
    Future.delayed(const Duration(seconds: 1), _autoAdvanceBanner);
  }

  void _autoAdvanceBanner() {
    myLog.log('Auto-advancing banner: current index $_bannerIndex');
    if (!mounted || _bannerCtrl == null) return;
    final count = ctrl.promoBanners.length;
    final next = (_bannerIndex + 1) % count;
    _bannerCtrl!.animateToPage(
      next,
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOut,
    );
    Future.delayed(const Duration(seconds: 5), _autoAdvanceBanner);
  }

  @override
  void dispose() {
    _bannerCtrl?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Get.find<ThemeController>();

    return AnimatedBuilder(
      animation: theme,
      builder: (_, __) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final bg = isDark ? const Color(0xFF0d0d0f) : const Color(0xFFF2F2F7);
        final onBg =
            !isDark ? const Color(0xFF0d0d0f) : const Color(0xFFF2F2F7);
        final cardBg =
            isDark ? const Color.fromARGB(255, 33, 35, 36) : Colors.white;
        final txt = isDark ? Colors.white : const Color(0xFF1a1a1a);
        final sub = isDark ? Colors.grey[400]! : Colors.grey[600]!;
        final divClr = isDark ? const Color(0xFF2a2a2a) : Colors.grey[200]!;

        return Scaffold(
          backgroundColor: bg,
          body: SafeArea(
            bottom: false,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    spacing: 8,
                    children: [
                      CustomImageView(
                        radius: BorderRadius.circular(8),
                        imagePath: 'assets/images/1024.png',
                        width: 30,
                        height: 30,
                      ),
                      Text(
                        'NoveluX',
                        style: TextStyle(
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          color: depperBlue,
                          fontFamily: 'Poppins',
                        ),
                      ),
                      Spacer(),
                      GestureDetector(
                        onTap: () => Get.to(() => RewardsScreen()),
                        child: Container(
                          margin: EdgeInsets.all(8),
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: depperBlue,
                            shape: BoxShape.circle,
                          ),
                          child: Stack(
                            clipBehavior: Clip.none,

                            children: [
                              Icon(LucideIcons.gift500),
                              Positioned(
                                top: 20,
                                // left: 1,
                                // right: 1,
                                child: Container(
                                  padding: EdgeInsets.all(3),
                                  margin: EdgeInsets.only(right: 16),
                                  decoration: BoxDecoration(
                                    color: depperBlue,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Center(
                                    child: Text(
                                      'Check In',

                                      style: TextStyle(
                                        fontSize: 10,
                                        fontFamily: 'Poppins',
                                        fontWeight: FontWeight.w500,
                                        color: txt,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // ── Search bar ────────────────────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap:
                              () => Get.to(
                                () => const SearchScreen(),
                                transition: Transition.cupertino,
                              ),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 11,
                            ),
                            decoration: BoxDecoration(
                              color: cardBg,
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.search, color: onBg, size: 18),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: AnimatedTextKit(
                                    repeatForever: true,
                                    animatedTexts:
                                        [
                                              'Search novels, authors, genres...',
                                              'The Ashboard Crown',
                                              'Sweet chaos',
                                              "Luna's betrayal",
                                              'Unexpected desires',
                                            ]
                                            .map(
                                              (t) => FadeAnimatedText(
                                                t,
                                                textStyle: TextStyle(
                                                  color: txt,
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500,
                                                ),
                                                duration: const Duration(
                                                  milliseconds: 4500,
                                                ),
                                              ),
                                            )
                                            .toList(),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),

                // ── Scrollable body ───────────────────────────────────────────────
                Expanded(
                  child: RefreshIndicator(
                    onRefresh: ctrl.fetchAll,
                    color: depperBlue,
                    // KEY FIX: Use CustomScrollView with SliverList — no nested scrollviews
                    child: CustomScrollView(
                      physics: const BouncingScrollPhysics(
                        parent: AlwaysScrollableScrollPhysics(),
                      ),
                      slivers: [
                        // ── Featured carousel ────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.featured.isNotEmpty
                                    ? _sectionWidget(
                                      'Weekly Featured',
                                      cardBg,
                                      onBg,
                                      txt,
                                      _buildFeaturedCarousel(),
                                    )
                                    : ctrl.isLoadingFeatured.value
                                    ? _sectionWidget(
                                      'Featured',
                                      cardBg,
                                      onBg,
                                      txt,
                                      _shimmerRow(height: 170),
                                    )
                                    : const SizedBox.shrink(),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── For You ──────────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: _sectionWidget(
                            'For You',
                            cardBg,
                            onBg,
                            txt,
                            Column(
                              children: [
                                // Preferred genre tabs
                                _forYouTabs(),
                                const SizedBox(height: 12),
                                Obx(
                                  () =>
                                      ctrl.isLoadingForYou.value
                                          ? _shimmerRow()
                                          : ctrl.forYou.isEmpty
                                          ? _emptyState('No stories found')
                                          : _storyRow(ctrl.forYou, txt),
                                ),
                              ],
                            ),
                            onViewAll:
                                () => Get.to(
                                  () => ViewAllScreen(
                                    section: SectionType.forYou,
                                  ),
                                  arguments: 'For You',
                                ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Promo banner (PageView — smooth, no conflict) ────────────
                        Obx(
                          () => SliverToBoxAdapter(
                            child:
                                ctrl.isLoadingBanners.value
                                    ? SizedBox.shrink()
                                    // Padding(
                                    //   padding: const EdgeInsets.all(8.0),
                                    //   child: Center(
                                    //     child: CircularProgressIndicator(
                                    //       color: depperBlue,
                                    //     ),
                                    //   ),
                                    // )
                                    : _buildPromoBanner(),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Best Novels ──────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: _sectionWidget(
                            'Best Novels',
                            cardBg,
                            onBg,
                            txt,
                            Column(
                              children: [
                                _tabRow(
                                  ['Must Read', 'Most Engaging', 'Top Rated'],
                                  _rankingIndex,
                                  (i) => setState(() => _rankingIndex = i),
                                ),
                                const SizedBox(height: 10),
                                Obx(
                                  () =>
                                      ctrl.trending.isEmpty
                                          ? _shimmerRow(height: 300)
                                          : _rankingsList(
                                            ctrl.trending,
                                            txt,
                                            sub,
                                          ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Trending ─────────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingTrending.value
                                    ? _shimmerRow()
                                    : ctrl.trending.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      'Trending Now',
                                      // Obx(
                                      cardBg,
                                      //   () =>
                                      //       ctrl.trending.isEmpty
                                      // ? SizedBox.shrink() //_shimmerRow()
                                      //:
                                      onBg,
                                      txt,
                                      _storyRow(ctrl.trending, txt),
                                      //  ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Completed ────────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingCompletedStories.value
                                    ? _shimmerRow()
                                    : ctrl.completedStories.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      'Completed Stories',
                                      cardBg,
                                      // Obx(
                                      //   () =>
                                      //       ctrl.completedStories.isEmpty
                                      //           ? SizedBox.shrink() //_shimmerRow()
                                      //:
                                      onBg,
                                      txt,
                                      _storyRow(ctrl.completedStories, txt),
                                      //  ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── World Famous ─────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingworldFamous.value
                                    ? _shimmerRow()
                                    : ctrl.worldFamous.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      'World Famous',
                                      // Obx(
                                      cardBg,
                                      //   () =>
                                      //       ctrl.worldFamous.isEmpty
                                      // ? SizedBox.shrink() //_shimmerRow()
                                      //:
                                      onBg,
                                      txt,
                                      _storyRow(ctrl.worldFamous, txt),
                                      // ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Free Download ─────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingFreeDownlaod.value
                                    ? _shimmerRow()
                                    : ctrl.freeDownLoad.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      'Free Download',
                                      // Obx(
                                      cardBg,
                                      onBg,
                                      txt,
                                      //   () =>
                                      //_shimmerRow()
                                      //:
                                      _storyRow(ctrl.freeDownLoad, txt),
                                      //  ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── African Folk Tale ─────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingAfricanFolkTale.value
                                    ? _shimmerRow()
                                    : ctrl.africanfolktale.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      'African Folk Tale',
                                      // Obx(
                                      //   () =>
                                      cardBg,
                                      //:
                                      onBg,
                                      txt,
                                      _storyRow(ctrl.africanfolktale, txt),
                                      // ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Editor's Pick ─────────────────────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingEditors.value
                                    ? _shimmerRow()
                                    : ctrl.editorsPick.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      "Editor's Pick",
                                      cardBg,
                                      // Obx(
                                      //   () =>
                                      //       ctrl.isLoadingEditors.value
                                      //
                                      //
                                      //      ? SizedBox.shrink()
                                      //:
                                      onBg,
                                      txt,
                                      _storyRow(ctrl.editorsPick, txt),
                                      // ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 10)),

                        // ── Featured For You (list style) ─────────────────────────────
                        SliverToBoxAdapter(
                          child: Obx(
                            () =>
                                ctrl.isLoadingFeatured.value
                                    ? _shimmerRow()
                                    : ctrl.featured.isEmpty
                                    ? SizedBox.shrink()
                                    : _sectionWidget(
                                      'Featured For You',
                                      cardBg,
                                      // Obx(
                                      //   () =>
                                      //       ctrl.featured.isEmpty
                                      //           ? SizedBox.shrink()
                                      //:
                                      onBg,
                                      txt,
                                      _featuredList(ctrl.featured, txt, sub),
                                      //               LazyStoryRow(
                                      //   stories: ctrl.trending,
                                      //   isLoading: ctrl.isLoadingTrending,
                                      //   isLoadingMore: ctrl.isLoadingMoreTrending,
                                      //   hasMore: ctrl.hasMoreTrending,
                                      //   onLoadMore: ctrl.loadMoreTrending,
                                      //   getCoverUrl: ctrl.getCoverUrl,
                                      // ),
                                      //  ),
                                    ),
                          ),
                        ),

                        const SliverToBoxAdapter(child: SizedBox(height: 100)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── For You tabs (preferred genres) ──────────────────────────────────────
  Widget _forYouTabs() => Obx(() {
    final tabs = ctrl.preferredGenres;
    return SizedBox(
      height: 30,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.only(left: 16),
        itemCount: tabs.length,
        itemBuilder: (_, i) {
          final tab = tabs[i];
          // Prettify slug label
          final label =
              tab == 'All'
                  ? 'All'
                  : tab.toString().replaceAll('-', ' ').capitalize;
          //.replaceAll('-', ' ');
          // .split(' ')
          // .map(
          //   (w) =>
          //       w.isEmpty
          //           ? ''
          //           :   w,//'${w[0].toUpperCase()}${w.substring(1)}',
          // )
          // .join(' ');
          final sel =
              ctrl.selectedForYouTab.value ==
              tab.replaceAll('-', ' ').capitalize;
          return GestureDetector(
            onTap: () {
              ctrl.filterForYou(label);
              setState(() {});
              print("atb ${tab.replaceAll('-', ' ')}");
              print(
                'Filtering For You byx: $tab, ${tabs[i]}; selected: ${ctrl.selectedForYouTab.value}',
              );
              //  setState(() => ctrl.selectedForYouTab.value = tab.toString());
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                color: sel ? depperBlue : const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                label!,
                style: TextStyle(
                  color: sel ? Colors.white : Colors.white70,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  });

  // ── Promo banner — PageView (smooth, doesn't steal scrolling) ────────────
  Widget _buildPromoBanner() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 10),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SizedBox(
        height: 100,
        child: Stack(
          children: [
            PageView.builder(
              controller: _bannerCtrl,
              itemCount:
                  ctrl.promoBanners.isEmpty ? 3 : ctrl.promoBanners.length,
              onPageChanged: (i) => setState(() => _bannerIndex = i),
              itemBuilder: (_, i) {
                List<dynamic> bannerList =
                    ctrl.promoBanners.isEmpty
                        ? ExploreController.defaultBanners
                        : ctrl.promoBanners;
                final banner = bannerList[i];
                return GestureDetector(
                  onTap: () {
                    final slug = banner['slug'] as String;
                    if (slug.isNotEmpty) {
                      Navigator.push(
                        context,
                        CupertinoPageRoute(
                          builder: (_) => StoryDetailScreen(slug: slug),
                        ),
                      );
                    }
                  },
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      _bannerImage(banner),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              Colors.black.withOpacity(0.6),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 10,
                        left: 12,
                        child: Text(
                          banner['title'] as String,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            // Dot indicators
            Positioned(
              bottom: 8,
              right: 12,
              child: Row(
                children: List.generate(
                  (ctrl.promoBanners.isEmpty ? 3 : ctrl.promoBanners.length),
                  (i) => AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    margin: const EdgeInsets.only(left: 4),
                    width: _bannerIndex == i ? 14 : 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: _bannerIndex == i ? depperBlue : Colors.white54,
                      borderRadius: BorderRadius.circular(3),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );

  // ── Featured carousel (CarouselView replacement — PageView) ──────────────
  // Widget _buildFeaturedCarousel() => Obx(() {
  //   if (ctrl.featured.isEmpty) {
  //     return const SizedBox(
  //       height: 170,
  //       child: Center(child: CircularProgressIndicator(color: Colors.orange)),
  //     );
  //   }
  //   return SizedBox(
  //     height: 170,
  //     child: PageView.builder(
  //       controller: PageController(viewportFraction: 0.85),
  //       itemCount: ctrl.featured.length,
  //       itemBuilder: (_, i) {
  //         final story = ctrl.featured[i];
  //         final coverUrl = ctrl.getCoverUrl(story);
  //         return GestureDetector(
  //           onTap:
  //               () => Navigator.push(
  //                 context,
  //                 CupertinoPageRoute(
  //                   builder: (_) => StoryDetailScreen(slug: story['slug']),
  //                 ),
  //               ),
  //           child: Container(
  //             margin: const EdgeInsets.only(right: 10),
  //             decoration: BoxDecoration(
  //               borderRadius: BorderRadius.circular(12),
  //               color: const Color(0xFF2A2A2A),
  //             ),
  //             child: ClipRRect(
  //               borderRadius: BorderRadius.circular(12),
  //               child: Stack(
  //                 fit: StackFit.expand,
  //                 children: [
  //                   coverUrl.isNotEmpty
  //                       ? CustomImageView(
  //                         imagePath: coverUrl,
  //                         fit: BoxFit.cover,
  //                       )
  //                       : _bookPlaceholder(),
  //                   Container(
  //                     decoration: BoxDecoration(
  //                       gradient: LinearGradient(
  //                         begin: Alignment.topCenter,
  //                         end: Alignment.bottomCenter,
  //                         colors: [
  //                           Colors.transparent,
  //                           Colors.black.withOpacity(0.85),
  //                         ],
  //                       ),
  //                     ),
  //                   ),
  //                   // Rating badge
  //                   Positioned(
  //                     top: 10,
  //                     right: 10,
  //                     child: Container(
  //                       padding: const EdgeInsets.symmetric(
  //                         horizontal: 6,
  //                         vertical: 3,
  //                       ),
  //                       decoration: BoxDecoration(
  //                         color: depperBlue,
  //                         borderRadius: BorderRadius.circular(6),
  //                       ),
  //                       child: Text(
  //                         '${story['average_rating']} ⭐',
  //                         style: const TextStyle(
  //                           color: Colors.white,
  //                           fontSize: 10,
  //                           fontWeight: FontWeight.bold,
  //                         ),
  //                       ),
  //                     ),
  //                   ),
  //                   Positioned(
  //                     bottom: 12,
  //                     left: 12,
  //                     right: 12,
  //                     child: Column(
  //                       crossAxisAlignment: CrossAxisAlignment.start,
  //                       children: [
  //                         Text(
  //                           story['title'] ?? '',
  //                           style: const TextStyle(
  //                             color: Colors.white,
  //                             fontSize: 15,
  //                             fontWeight: FontWeight.w900,
  //                           ),
  //                           maxLines: 1,
  //                           overflow: TextOverflow.ellipsis,
  //                         ),
  //                         const SizedBox(height: 4),
  //                         Text(
  //                           story['description'] ?? '',
  //                           style: const TextStyle(
  //                             color: Colors.white70,
  //                             fontSize: 11,
  //                           ),
  //                           maxLines: 2,
  //                           overflow: TextOverflow.ellipsis,
  //                         ),
  //                       ],
  //                     ),
  //                   ),
  //                 ],
  //               ),
  //             ),
  //           ),
  //         );
  //       },
  //     ),
  //   );
  // });

  Widget _buildFeaturedCarousel() => Obx(() {
    if (ctrl.featured.isEmpty) {
      return const SizedBox(
        height: 170,
        child: Center(child: CircularProgressIndicator(color: Colors.blue)),
      );
    }
    return Container(
      height: 170,
      child: CarouselView(
        itemExtent:
            MediaQuery.of(context).size.width *
            0.8, // Shows 80% of one card, hinting at the next
        shrinkExtent:
            MediaQuery.of(context).size.width *
            0.7, // Minimum size when shrinking
        children:
            ctrl.featured.map((story) {
              final coverUrl = ctrl.getCoverUrl(story);
              return Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    myLog.log('pushing now');
                    Navigator.push(
                      context,
                      CupertinoPageRoute(
                        builder: (_) => StoryDetailScreen(slug: story['slug']),
                      ),
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: const Color(0xFF2A2A2A),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Stack(
                        children: [
                          // ✅ Force image to fill entire container
                          Positioned.fill(
                            child:
                                coverUrl.isNotEmpty
                                    ? CustomImageView(
                                      imagePath: coverUrl,
                                      fit: BoxFit.cover,
                                      placeHolder: coverUrl,
                                    )
                                    : _bookPlaceholder(),
                          ),

                          // ✅ Bottom gradient overlay
                          Positioned(
                            bottom: 0,
                            left: 0,
                            right: 0,
                            child: Container(
                              height: 100,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Colors.transparent,
                                    Colors.black.withOpacity(1),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          Positioned(
                            top: 10,
                            right: 10,
                            child: Container(
                              padding: EdgeInsets.all(3),
                              decoration: BoxDecoration(
                                color: depperBlue,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                children: [
                                  ...(story['total_views'] != null
                                      ? [
                                        Text(
                                          '${story['total_views']} Views ',
                                          style: TextStyle(
                                            color: Colors.white70,
                                            fontSize: 10,
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ]
                                      : []),
                                  Text(
                                    ' ${story['average_rating']} ⭐',
                                    style: TextStyle(
                                      color: Colors.white70,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // ✅ Text
                          Positioned(
                            bottom: 12,
                            left: 12,
                            right: 12,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  story['title'] ?? '',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w900,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  story['description'] ?? '',
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 12,
                                    fontFamily: 'Poppins',
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
      ),
    );
  });

  // ── Section wrapper ───────────────────────────────────────────────────────
  Widget _sectionWidget(
    String title,
    Color cardbg,
    Color onbg,
    Color txt,
    Widget child, {
    VoidCallback? onViewAll,
  }) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(12),
      color: cardbg,
    ),
    child: Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  // VerticalDivider(color: depperBlue, thickness: 3, width: 10),
                  Container(
                    width: 4,
                    height: 20,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(2),
                      color: depperBlue,
                    ),
                    margin: const EdgeInsets.only(right: 8),
                  ),
                  Text(
                    title,
                    style: TextStyle(
                      color: txt,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              if (!(title.contains('Featured')))
                GestureDetector(
                  onTap:
                      onViewAll ??
                      () => Get.to(
                        () => ViewAllScreen(section: SectionType.featured),
                        arguments: title,
                      ),
                  child: Row(
                    children: [
                      Text(
                        'View all',
                        style: TextStyle(color: txt, fontSize: 12),
                      ),
                      Icon(Icons.chevron_right, color: onbg, size: 16),
                    ],
                  ),
                ),
            ],
          ),
        ),
        child,
        const SizedBox(height: 10),
      ],
    ),
  );

  Widget _tabRow(List<String> tabs, int selected, Function(int) onTap) =>
      SizedBox(
        height: 28,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.only(left: 16),
          itemCount: tabs.length,
          itemBuilder: (_, i) {
            final sel = i == selected;
            return GestureDetector(
              onTap: () => onTap(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: sel ? depperBlue : const Color(0xFF2A2A2A),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  tabs[i],
                  style: TextStyle(
                    color: sel ? Colors.white : Colors.white70,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
        ),
      );

  Widget _storyRow(RxList stories, Color txt) => SizedBox(
    height: 200,
    child: ListView.builder(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: stories.length,
      // KEY: use NeverScrollableScrollPhysics so it doesn't fight parent
      physics: const BouncingScrollPhysics(),
      itemBuilder: (_, i) {
        final story = stories[i];
        final coverUrl = ctrl.getCoverUrl(story);
        final tags = (story['tags'] as List? ?? []);
        return GestureDetector(
          onTap:
              () => Navigator.push(
                context,
                CupertinoPageRoute(
                  builder: (_) => StoryDetailScreen(slug: story['slug']),
                ),
              ),
          child: SizedBox(
            width: 110,
            child: Container(
              margin: const EdgeInsets.only(right: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      height: 130,
                      width: 120,
                      child:
                          coverUrl.isNotEmpty
                              ? CustomImageView(
                                imagePath: coverUrl,
                                height: 125,
                                width: 100,
                                fit: BoxFit.cover,
                              )
                              : _bookPlaceholder(),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    story['title'] ?? '',
                    style: TextStyle(
                      color: txt,
                      fontSize: 14,
                      fontFamily: 'Poppins',
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (tags.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.only(top: 3),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: depperBlue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        tags[0]['name'] ?? '',
                        style: TextStyle(
                          color: depperBlue,
                          fontSize: 9,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    ),
  );

  Widget _rankingsList(RxList stories, Color txt, Color sub) => SizedBox(
    height: 330,
    child: GridView.builder(
      shrinkWrap: true,
      physics: const BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      itemCount: stories.length > 9 ? 9 : stories.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        mainAxisSpacing: 2,
        crossAxisSpacing: 2,
        childAspectRatio: 2.4 / 5.3,
        crossAxisCount: 3,
      ),
      itemBuilder: (_, i) {
        final story = stories[i];
        final coverUrl = ctrl.getCoverUrl(story);
        final tags = (story['tags'] as List? ?? []);
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
          child: GestureDetector(
            onTap:
                () => Navigator.push(
                  context,
                  CupertinoPageRoute(
                    builder: (_) => StoryDetailScreen(slug: story['slug']),
                  ),
                ),
            child: Row(
              children: [
                Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: SizedBox(
                        width: 75,
                        //height: 130,
                        child:
                            coverUrl.isNotEmpty
                                ? CustomImageView(
                                  // height: 130,
                                  // width: 10,
                                  imagePath: coverUrl,
                                  fit: BoxFit.cover,
                                )
                                : _bookPlaceholder(),
                      ),
                    ),
                    Positioned(
                      child: Container(
                        width: 16,
                        height: 20,
                        decoration: BoxDecoration(
                          color: i < 3 ? depperBlue : const Color(0xFFA9AA6C),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Center(
                          child: Text(
                            '${i + 1}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 10,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        story['title'] ?? '',
                        style: TextStyle(
                          color: txt,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        story['description'] ?? '',
                        style: TextStyle(
                          color: sub,
                          fontSize: 12,
                          fontFamily: 'Poppins',
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Text(
                            '${double.tryParse(story['average_rating'].toString())?.toStringAsFixed(1) ?? '0.0'}',
                            style: TextStyle(color: sub, fontSize: 10),
                          ),
                          const Icon(Icons.star, color: Colors.amber, size: 10),
                          const SizedBox(width: 6),
                          Text(
                            '${story['total_views'] ?? 0} views',
                            style: TextStyle(color: sub, fontSize: 10),
                          ),
                        ],
                      ),
                      if (tags.isNotEmpty)
                        Container(
                          margin: const EdgeInsets.only(top: 4),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: depperBlue.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            tags[0]['name'] ?? '',
                            style: TextStyle(
                              color: depperBlue,
                              fontSize: 10,

                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );

  Widget _featuredList(RxList stories, txt, sub) => Column(
    children:
        stories.
        //take(6).
        map((story) {
          final coverUrl = ctrl.getCoverUrl(story);
          final tags = (story['tags'] as List? ?? []);
          return GestureDetector(
            onTap:
                () => Navigator.push(
                  context,
                  CupertinoPageRoute(
                    builder: (_) => StoryDetailScreen(slug: story['slug']),
                  ),
                ),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: SizedBox(
                      width: 75,
                      height: 100,
                      child:
                          coverUrl.isNotEmpty
                              ? CustomImageView(
                                imagePath: coverUrl,
                                fit: BoxFit.cover,
                              )
                              : _bookPlaceholder(),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          story['title'] ?? '',
                          style: TextStyle(
                            color: txt,
                            fontSize: 14,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w700,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          story['description'] ?? '',
                          style: TextStyle(
                            color: sub,
                            fontSize: 12,
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.w400,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Text(
                              '${double.tryParse(story['average_rating'].toString())?.toStringAsFixed(1) ?? '0.0'}',
                              style: TextStyle(color: sub, fontSize: 11),
                            ),
                            const Icon(
                              Icons.star,
                              color: Colors.amber,
                              size: 12,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              '${story['total_views'] ?? 0} views',
                              style: TextStyle(color: sub, fontSize: 11),
                            ),
                          ],
                        ),
                        if (tags.isNotEmpty)
                          Wrap(
                            spacing: 6,
                            children:
                                tags
                                    .take(2)
                                    .map(
                                      (t) => Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: depperBlue.withOpacity(0.15),
                                          borderRadius: BorderRadius.circular(
                                            4,
                                          ),
                                        ),
                                        child: Text(
                                          t['name'] ?? '',
                                          style: TextStyle(
                                            color: depperBlue,
                                            fontSize: 10,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                      ),
                                    )
                                    .toList(),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
  );

  Widget _bannerImage(dynamic banner) {
    final img = ctrl.getBannerImageUrl(banner as Map);
    if (img.isEmpty) {
      return Container(
        color: const Color(0xFF2a2a2a),
        child: const Center(
          child: Icon(Icons.image_outlined, color: Colors.grey, size: 32),
        ),
      );
    }
    if (img.startsWith('assets/')) {
      return Image.asset(img, fit: BoxFit.cover);
    }
    return CustomImageView(imagePath: img, fit: BoxFit.cover);
  }

  Widget _shimmerRow({double height = 160}) => Shimmer(
    gradient: LinearGradient(
      colors: [Colors.grey[800]!, Colors.grey[700]!, Colors.grey[800]!],
      stops: const [0.1, 0.3, 0.4],
      begin: const Alignment(-1, -0.3),
      end: const Alignment(1, 0.3),
    ),
    child: SizedBox(
      height: height,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: 4,
        itemBuilder:
            (_, __) => Container(
              width: 90,
              height: height,
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
      ),
    ),
  );

  Widget _emptyState(String msg) => Padding(
    padding: const EdgeInsets.all(24),
    child: Center(
      child: Text(
        msg,
        style: const TextStyle(color: Colors.grey, fontSize: 13),
      ),
    ),
  );

  Widget _bookPlaceholder() => Container(
    color: const Color(0xFF2A2A2A),
    child: const Center(child: Icon(Icons.book, color: Colors.grey, size: 30)),
  );

  void _showSearch(BuildContext context) {
    showSearch(context: context, delegate: _StorySearchDelegate(ctrl));
  }
}

// ── Search delegate ────────────────────────────────────────────────────────────
class _StorySearchDelegate extends SearchDelegate {
  final ExploreController ctrl;
  _StorySearchDelegate(this.ctrl);

  @override
  ThemeData appBarTheme(BuildContext context) => ThemeData.dark().copyWith(
    appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF1a1a1a)),
  );

  @override
  List<Widget> buildActions(BuildContext context) => [
    IconButton(icon: const Icon(Icons.clear), onPressed: () => query = ''),
  ];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
    icon: const Icon(Icons.arrow_back),
    onPressed: () => close(context, null),
  );

  @override
  Widget buildResults(BuildContext context) {
    ctrl.search(query);
    return Obx(
      () => ListView.builder(
        itemCount: ctrl.forYou.length,
        itemBuilder: (_, i) {
          final story = ctrl.forYou[i];
          return ListTile(
            leading: const Icon(Icons.book, color: Colors.grey),
            title: Text(
              story['title'] ?? '',
              style: const TextStyle(color: Colors.white),
            ),
            subtitle: Text(
              story['author']?['username'] ?? '',
              style: const TextStyle(color: Colors.grey),
            ),
            onTap: () {
              close(context, null);
              Navigator.push(
                context,
                CupertinoPageRoute(
                  builder: (_) => StoryDetailScreen(slug: story['slug']),
                ),
              );
            },
          );
        },
      ),
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) => buildResults(context);
}
