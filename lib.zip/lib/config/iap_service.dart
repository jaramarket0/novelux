// ══════════════════════════════════════════════════════════════════════════════
//  NoveluX IAP Service — Google Play Billing only
//  File: lib/services/iap_service.dart
//
//  pubspec.yaml — add ONLY these two:
//    in_app_purchase: ^3.2.0
//    in_app_purchase_android: ^0.3.5+1
//
//  Google Play Console setup:
//  ┌──────────────────────────────────────────────────────────────────────────┐
//  │  SUBSCRIPTIONS (Monetize → Products → Subscriptions → Create)           │
//  │    novelux_vip_monthly  — Monthly, set price in ₦                       │
//  │    novelux_vip_yearly   — Yearly,  set price in ₦                       │
//  │    novelux_vip_weekly   — Weekly,  set price in ₦                       │
//  │                                                                          │
//  │  IN-APP PRODUCTS (Monetize → Products → In-app products → Create)       │
//  │    novelux_coins_100   — Managed / Consumable                           │
//  │    novelux_coins_500   — Managed / Consumable                           │
//  │    novelux_coins_1200  — Managed / Consumable                           │
//  │    novelux_coins_3000  — Managed / Consumable                           │
//  │                                                                          │
//  │  ⚠ All products must be ACTIVE in Play Console before the SDK           │
//  │    can load them. Draft products return empty results.                   │
//  └──────────────────────────────────────────────────────────────────────────┘
//
//  How it works:
//  1. IAPService registers as a GetxService singleton at app start
//  2. It immediately shows fallback ₦ prices so UI is never empty
//  3. It queries the real Play Store prices in the background
//  4. When user buys: Play handles the payment dialog
//  5. On success: send receipt to your backend → backend grants VIP/coins
//  6. Handles pending transactions, upgrades, and restore automatically
//
// ══════════════════════════════════════════════════════════════════════════════

import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/billing_client_wrappers.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';

import 'package:novelux/config/api_service.dart';
// import 'package:purchases_flutter/purchases_flutter.dart';
import 'dart:developer' as myLog;

// ══════════════════════════════════════════════════════════════════════════════
//  PRODUCT IDs — must match Play Console exactly
// ══════════════════════════════════════════════════════════════════════════════

const kSubMonthly = 'novelux_vip_monthly';
const kSubYearly = 'novelux_vip_yearly';
const kSubWeekly = 'novelux_vip_weekly';

const kCoins100 = 'novelux_coins_100';
const kCoins500 = 'novelux_coins_500';
const kCoins1200 = 'novelux_coins_1200';
const kCoins3000 = 'novelux_coins_3000';

const _kSubIds = {kSubMonthly, kSubYearly, kSubWeekly};
const _kCoinIds = {kCoins100, kCoins500, kCoins1200, kCoins3000};
const _kAllIds = {..._kSubIds, ..._kCoinIds};

// ══════════════════════════════════════════════════════════════════════════════
//  DATA MODELS
// ══════════════════════════════════════════════════════════════════════════════

enum PurchaseStatus2 { success, cancelled, error, pending }

class PurchaseResult {
  final PurchaseStatus2 status;
  final String? message;
  final int? coinsGranted;
  final bool isVip;

  const PurchaseResult._({
    required this.status,
    this.message,
    this.coinsGranted,
    this.isVip = false,
  });

  factory PurchaseResult.success({int? coins, bool vip = false, String? msg}) =>
      PurchaseResult._(
        status: PurchaseStatus2.success,
        coinsGranted: coins,
        isVip: vip,
        message: msg,
      );

  factory PurchaseResult.cancelled() =>
      const PurchaseResult._(status: PurchaseStatus2.cancelled);

  factory PurchaseResult.error(String msg) =>
      PurchaseResult._(status: PurchaseStatus2.error, message: msg);

  factory PurchaseResult.pending() =>
      const PurchaseResult._(status: PurchaseStatus2.pending);

  bool get ok => status == PurchaseStatus2.success;
  bool get wasCancelled => status == PurchaseStatus2.cancelled;
  bool get failed => status == PurchaseStatus2.error;
}

// ── VIP plan ─────────────────────────────────────────────────────────────────

class VipPlan {
  final String id;
  final String name;
  final String price; // from store, or fallback
  final String period;
  final String? badge;
  final bool isPrimary;
  final ProductDetails? product; // null until store responds

  const VipPlan({
    required this.id,
    required this.name,
    required this.price,
    required this.period,
    this.badge,
    this.isPrimary = false,
    this.product,
  });

  VipPlan copyWith({String? price, ProductDetails? product}) => VipPlan(
    id: id,
    name: name,
    period: period,
    badge: badge,
    isPrimary: isPrimary,
    price: price ?? this.price,
    product: product ?? this.product,
  );
}

// ── Coin pack ─────────────────────────────────────────────────────────────────

class CoinPack {
  final String id;
  final int coins;
  final String label;
  final String price;
  final String? bonus;
  final bool isPopular;
  final ProductDetails? product;

  const CoinPack({
    required this.id,
    required this.coins,
    required this.label,
    required this.price,
    this.bonus,
    this.isPopular = false,
    this.product,
  });

  CoinPack copyWith({String? price, ProductDetails? product}) => CoinPack(
    id: id,
    coins: coins,
    label: label,
    bonus: bonus,
    isPopular: isPopular,
    price: price ?? this.price,
    product: product ?? this.product,
  );
}

// ══════════════════════════════════════════════════════════════════════════════
//  IAP SERVICE
// ══════════════════════════════════════════════════════════════════════════════

class IAPService extends GetxService {
  static IAPService get to => Get.find<IAPService>();

  // ── Observable state ────────────────────────────────────────────────────────
  final RxBool storeAvailable = false.obs;
  final RxBool isLoadingPrices = false.obs; // background price fetch
  final RxBool isPurchasing = false.obs;
  final RxBool isVip = false.obs;
  final RxString activeSubId = ''.obs;
  final RxString errorMsg = ''.obs;

  final RxList<VipPlan> vipPlans = <VipPlan>[].obs;
  final RxList<CoinPack> coinPacks = <CoinPack>[].obs;

  // ── Fallback prices shown immediately before store responds ─────────────────
  static const _defaultPlans = [
    VipPlan(
      id: kSubMonthly,
      name: 'Monthly',
      price: '₦4,999',
      period: '/mo',
      badge: 'Most Popular',
      isPrimary: true,
    ),
    VipPlan(
      id: kSubYearly,
      name: 'Yearly',
      price: '₦39,999',
      period: '/yr',
      badge: 'Save 33%',
    ),
    VipPlan(id: kSubWeekly, name: 'Weekly', price: '₦1,499', period: '/wk'),
  ];

  static const _defaultPacks = [
    CoinPack(id: kCoins100, coins: 100, label: '100 Coins', price: '₦500'),
    CoinPack(
      id: kCoins500,
      coins: 500,
      label: '500 Coins',
      price: '₦2,000',
      bonus: '+50 bonus',
      isPopular: true,
    ),
    CoinPack(
      id: kCoins1200,
      coins: 1200,
      label: '1,200 Coins',
      price: '₦4,500',
      bonus: '+200 bonus',
    ),
    CoinPack(
      id: kCoins3000,
      coins: 3000,
      label: '3,000 Coins',
      price: '₦9,999',
      bonus: '+600 bonus',
    ),
  ];

  // ── Internal ────────────────────────────────────────────────────────────────
  final _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  // Completers let buySubscription/buyCoins await the purchase stream result
  final Map<String, Completer<PurchaseResult>> _pending = {};

  // ══════════════════════════════════════════════════════════════════════════
  //  LIFECYCLE
  // ══════════════════════════════════════════════════════════════════════════

  @override
  Future<void> onInit() async {
    super.onInit();

    // Populate with fallback prices immediately — no blank state
    vipPlans.value = List.from(_defaultPlans);
    coinPacks.value = List.from(_defaultPacks);

    // Check store availability
    storeAvailable.value = await _iap.isAvailable();

    if (!storeAvailable.value) {
      debugPrint('[IAP] Play Store not available on this device');
      return;
    }

    // Listen to all purchase events for the entire app lifetime
    _sub = _iap.purchaseStream.listen(
      _onPurchaseUpdate,
      onError: (Object e) {
        errorMsg.value = 'Store error: $e';
        isPurchasing.value = false;
        debugPrint('[IAP] purchaseStream error: $e');
      },
    );

    // Fetch real prices in background — UI already showing fallback
    _fetchPrices();

    // Check if user already has VIP from the backend
    _checkVipStatus();
  }

  @override
  void onClose() {
    _sub?.cancel();
    super.onClose();
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  FETCH REAL PRICES FROM PLAY STORE
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> _fetchPrices() async {
    isLoadingPrices.value = true;
    try {
      final response = await _iap.queryProductDetails(_kAllIds);

      if (response.error != null) {
        debugPrint('[IAP] queryProductDetails error: ${response.error}');
      }

      if (response.notFoundIDs.isNotEmpty) {
        debugPrint(
          '[IAP] Products NOT found in Play Console '
          '(make sure they are ACTIVE, not draft): '
          '${response.notFoundIDs.join(', ')}',
        );
      }

      final products = response.productDetails;
      if (products.isEmpty) {
        debugPrint(
          '[IAP] No products returned — '
          'using fallback prices. '
          'Check Play Console product status.',
        );
        isLoadingPrices.value = false;
        return;
      }

      // Merge real prices into VipPlan list
      vipPlans.value =
          _defaultPlans.map((plan) {
            final p = products.firstWhereOrNull((x) => x.id == plan.id);
            return p != null ? plan.copyWith(price: p.price, product: p) : plan;
          }).toList();

      // Merge real prices into CoinPack list
      coinPacks.value =
          _defaultPacks.map((pack) {
            final p = products.firstWhereOrNull((x) => x.id == pack.id);
            return p != null ? pack.copyWith(price: p.price, product: p) : pack;
          }).toList();

      debugPrint('[IAP] Loaded ${products.length} products from Play Store');
    } catch (e) {
      debugPrint('[IAP] _fetchPrices error: $e');
    }
    isLoadingPrices.value = false;
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  BUY SUBSCRIPTION
  // ══════════════════════════════════════════════════════════════════════════

  /// Purchase a VIP subscription.
  /// Always returns — never throws. Caller checks [PurchaseResult.ok].
  Future<PurchaseResult> buySubscription(String productId) async {
    if (isPurchasing.value) {
      return PurchaseResult.error('A purchase is already in progress.');
    }
    if (!storeAvailable.value) {
      return PurchaseResult.error(
        'Google Play is not available on this device.',
      );
    }

    errorMsg.value = '';

    final plan = vipPlans.firstWhereOrNull((p) => p.id == productId);
    final product = plan?.product;

    if (product == null) {
      // Products not yet loaded from store (still showing fallback)
      // Retry fetching then try again
      if (!isLoadingPrices.value) await _fetchPrices();
      final retried =
          vipPlans.firstWhereOrNull((p) => p.id == productId)?.product;
      if (retried == null) {
        return PurchaseResult.error(
          'Product not available yet. Please wait a moment and try again.',
        );
      }
      return _launchPurchase(retried, isSubscription: true);
    }

    return _launchPurchase(product, isSubscription: true);
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  BUY COINS  (one-time consumable)
  // ══════════════════════════════════════════════════════════════════════════

  Future<PurchaseResult> buyCoins(String productId) async {
    myLog.log('Attempting to buy coins: $productId');
    if (isPurchasing.value) {
      return PurchaseResult.error('A purchase is already in progress.');
    }
    if (!storeAvailable.value) {
      return PurchaseResult.error(
        'Google Play is not available on this device.',
      );
    }
    myLog.log('Store is available.');

    errorMsg.value = '';
    myLog.log('Fetching coin pack: ${coinPacks.first.label}');
    myLog.log(
      '${coinPacks.first.id}Looking for productId in coinPacks: $productId',
    );
    final pack = coinPacks.firstWhereOrNull((p) => p.id == productId);
    final product = pack?.product;

    product == null
        ? myLog.log('Product not found in coinPacks: $productId')
        : myLog.log(
          'Found product in coinPacks: ${product.id} - ${product.price}',
        );

    if (product == null) {
      if (!isLoadingPrices.value) await _fetchPrices();
      final retried =
          coinPacks.firstWhereOrNull((p) => p.id == productId)?.product;
      if (retried == null) {
        return PurchaseResult.error(
          'Product not available yet. Please try again shortly.',
        );
      }
      return _launchPurchase(retried, isSubscription: false);
    }

    return _launchPurchase(product, isSubscription: false);
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  INTERNAL: LAUNCH A PLAY STORE PURCHASE DIALOG
  // ══════════════════════════════════════════════════════════════════════════

  Future<PurchaseResult> _launchPurchase(
    ProductDetails product, {
    required bool isSubscription,
  }) async {
    final completer = Completer<PurchaseResult>();
    _pending[product.id] = completer;
    isPurchasing.value = true;

    late PurchaseParam param;
    if (Platform.isAndroid) {
      ChangeSubscriptionParam? changeParam;

      // Fix for the 'fromMap' and 'prorationMode' errors
      if (isSubscription && activeSubId.value.isNotEmpty) {
        changeParam = ChangeSubscriptionParam(
          oldPurchaseDetails: GooglePlayPurchaseDetails(
            productID: activeSubId.value,
            billingClientPurchase: PurchaseWrapper(
              orderId: '',
              packageName:
                  'com.novelux.app', // Replace with your actual package name
              purchaseToken: '',
              signature: '',
              originalJson: '',
              purchaseTime: 0,
              purchaseState: PurchaseStateWrapper.purchased,
              isAcknowledged: true,
              products: [activeSubId.value],
              isAutoRenewing: true,
            ),
            verificationData: PurchaseVerificationData(
              localVerificationData: '',
              serverVerificationData: '',
              source: kIAPSource,
            ),
            transactionDate: DateTime.now().millisecondsSinceEpoch.toString(),
            status: PurchaseStatus.purchased,
          ),
          // Use replacementMode instead of prorationMode
          replacementMode: ReplacementMode.withTimeProration,
        );
      }

      param = GooglePlayPurchaseParam(
        productDetails: product,
        changeSubscriptionParam: changeParam,
      );
    } else {
      param = PurchaseParam(productDetails: product);
    }

    try {
      bool ok;
      if (isSubscription) {
        ok = await _iap.buyNonConsumable(purchaseParam: param);
      } else {
        ok = await _iap.buyConsumable(purchaseParam: param, autoConsume: false);
      }

      if (!ok) {
        _pending.remove(product.id);
        isPurchasing.value = false;
        return PurchaseResult.error('Could not initiate purchase.');
      }
    } catch (e) {
      _pending.remove(product.id);
      isPurchasing.value = false;
      return PurchaseResult.error(e.toString());
    }

    // Await the result from purchaseStream (timeout 5 min)
    return completer.future.timeout(
      const Duration(minutes: 5),
      onTimeout: () {
        _pending.remove(product.id);
        isPurchasing.value = false;
        return PurchaseResult.error(
          'Purchase timed out. Check Google Play for status.',
        );
      },
    );
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  PURCHASE STREAM HANDLER
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> _onPurchaseUpdate(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      debugPrint(
        '[IAP] purchaseStream: ${purchase.productID} '
        '→ ${purchase.status}',
      );

      switch (purchase.status) {
        case PurchaseStatus.pending:
          // Play is processing — keep spinner visible
          isPurchasing.value = true;
          break;

        case PurchaseStatus.purchased:
        case PurchaseStatus.restored:
          await _handleSuccessfulPurchase(purchase);
          break;

        case PurchaseStatus.error:
          isPurchasing.value = false;
          final msg = purchase.error?.message ?? 'Purchase failed.';
          errorMsg.value = msg;
          _resolve(purchase.productID, PurchaseResult.error(msg));
          break;

        case PurchaseStatus.canceled:
          isPurchasing.value = false;
          _resolve(purchase.productID, PurchaseResult.cancelled());
          break;
      }

      // Always acknowledge — required by Google Play
      if (purchase.pendingCompletePurchase) {
        await _iap.completePurchase(purchase);
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  HANDLE SUCCESSFUL PURCHASE — send to backend
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> _handleSuccessfulPurchase(PurchaseDetails purchase) async {
    final productId = purchase.productID;

    // Extract the Google Play purchase token (this is what your backend needs)
    final String purchaseToken;
    if (Platform.isAndroid) {
      final androidDetails = purchase as GooglePlayPurchaseDetails;
      purchaseToken = androidDetails.verificationData.serverVerificationData;
    } else {
      purchaseToken = purchase.verificationData.serverVerificationData;
    }

    debugPrint('[IAP] Sending receipt to backend for: $productId');

    try {
      final res = await ApiService.verifyPurchase(
        productId: productId,
        purchaseId: purchase.purchaseID ?? '',
        receipt: purchaseToken,
        platform: Platform.isAndroid ? 'android' : 'ios',
      );

      isPurchasing.value = false;

      if (res['success'] == true) {
        final isSubPurchase = _kSubIds.contains(productId);

        if (isSubPurchase) {
          isVip.value = true;
          activeSubId.value = productId;
          _resolve(purchase.productID, PurchaseResult.success(vip: true));
        } else {
          final coinsGranted =
              (res['data']?['coins_granted'] as num?)?.toInt() ?? 0;
          _resolve(
            purchase.productID,
            PurchaseResult.success(coins: coinsGranted),
          );
        }
      } else {
        final errMsg =
            res['error']?.toString() ??
            'Backend could not verify purchase. Contact support.';
        errorMsg.value = errMsg;
        _resolve(purchase.productID, PurchaseResult.error(errMsg));
      }
    } catch (e) {
      isPurchasing.value = false;
      final errMsg =
          'Verification failed: $e\nYour payment was NOT charged twice — '
          'contact support if needed.';
      _resolve(purchase.productID, PurchaseResult.error(errMsg));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  RESTORE PURCHASES
  // ══════════════════════════════════════════════════════════════════════════

  /// Re-delivers all non-consumed purchases via purchaseStream.
  /// Call when user taps "Restore purchases".
  Future<PurchaseResult> restorePurchases() async {
    if (!storeAvailable.value) {
      return PurchaseResult.error('Store not available.');
    }

    isPurchasing.value = true;
    try {
      await _iap.restorePurchases();
      // Results come through _onPurchaseUpdate above.
      // Give it 8 seconds to deliver any restored purchases.
      await Future.delayed(const Duration(seconds: 8));
      isPurchasing.value = false;

      if (isVip.value) {
        return PurchaseResult.success(vip: true, msg: 'VIP restored!');
      }
      return PurchaseResult.error(
        'No active subscription found on this Google account.',
      );
    } catch (e) {
      isPurchasing.value = false;
      return PurchaseResult.error('Restore failed: $e');
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  //  VIP STATUS CHECK (from backend)
  // ══════════════════════════════════════════════════════════════════════════

  Future<void> _checkVipStatus() async {
    try {
      final res = await ApiService.getVipStatus();
      if (res['success'] == true) {
        isVip.value = res['data']?['is_vip'] == true;
        activeSubId.value = res['data']?['plan_id'] ?? '';
        debugPrint('[IAP] VIP status from backend: ${isVip.value}');
      }
    } catch (e) {
      debugPrint('[IAP] VIP status check failed: $e');
    }
  }

  // Refresh on demand (call after login)
  Future<void> refreshVipStatus() => _checkVipStatus();

  // ══════════════════════════════════════════════════════════════════════════
  //  HELPERS
  // ══════════════════════════════════════════════════════════════════════════

  void _resolve(String productId, PurchaseResult result) {
    _pending[productId]?.complete(result);
    _pending.remove(productId);
  }
}
